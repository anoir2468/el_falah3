// lib/shared/models/user_model.dart
import 'package:cloud_firestore/cloud_firestore.dart';

@immutable
class UserModel {
  final String uid;
  final String email;
  final String fullName;
  final String phone;
  final UserType userType;
  final String wilaya;
  final String baladiya;
  final DateTime createdAt;
  final bool isEmailVerified;
  final String? profileImage;
  final String? bio;
  final double? rating;
  final int totalReviews;

  const UserModel({
    required this.uid,
    required this.email,
    required this.fullName,
    required this.phone,
    required this.userType,
    required this.wilaya,
    required this.baladiya,
    required this.createdAt,
    required this.isEmailVerified,
    this.profileImage,
    this.bio,
    this.rating = 0.0,
    this.totalReviews = 0,
  });

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'email': email,
      'fullName': fullName,
      'phone': phone,
      'userType': userType.name,
      'wilaya': wilaya,
      'baladiya': baladiya,
      'createdAt': createdAt.millisecondsSinceEpoch,
      'isEmailVerified': isEmailVerified,
      'profileImage': profileImage,
      'bio': bio,
      'rating': rating,
      'totalReviews': totalReviews,
      'updatedAt': FieldValue.serverTimestamp(),
    };
  }

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      uid: map['uid'] ?? '',
      email: map['email'] ?? '',
      fullName: map['fullName'] ?? '',
      phone: map['phone'] ?? '',
      userType: UserType.values.firstWhere(
        (e) => e.name == map['userType'],
        orElse: () => UserType.farmer,
      ),
      wilaya: map['wilaya'] ?? '',
      baladiya: map['baladiya'] ?? '',
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['createdAt']),
      isEmailVerified: map['isEmailVerified'] ?? false,
      profileImage: map['profileImage'],
      bio: map['bio'],
      rating: (map['rating'] ?? 0.0).toDouble(),
      totalReviews: map['totalReviews'] ?? 0,
    );
  }

  UserModel copyWith({
    String? fullName,
    String? phone,
    String? wilaya,
    String? baladiya,
    String? profileImage,
    String? bio,
    double? rating,
    int? totalReviews,
  }) {
    return UserModel(
      uid: uid,
      email: email,
      fullName: fullName ?? this.fullName,
      phone: phone ?? this.phone,
      userType: userType,
      wilaya: wilaya ?? this.wilaya,
      baladiya: baladiya ?? this.baladiya,
      createdAt: createdAt,
      isEmailVerified: isEmailVerified,
      profileImage: profileImage ?? this.profileImage,
      bio: bio ?? this.bio,
      rating: rating ?? this.rating,
      totalReviews: totalReviews ?? this.totalReviews,
    );
  }
}

enum UserType {
  farmer('فلاح'),
  worker('عامل'),
  supplier('تاجر'),
  trainer('مدرب');

  const UserType(this.arName);
  final String arName;
}