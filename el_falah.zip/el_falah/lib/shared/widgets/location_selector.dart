// lib/shared/widgets/location_selector.dart
class LocationSelector extends StatefulWidget {
  final String? selectedWilaya;
  final String? selectedBaladiya;
  final ValueChanged<String?> onWilayaChanged;
  final ValueChanged<String?> onBaladiyaChanged;
  final bool enabled;

  const LocationSelector({
    super.key,
    this.selectedWilaya,
    this.selectedBaladiya,
    required this.onWilayaChanged,
    required this.onBaladiyaChanged,
    this.enabled = true,
  });

  @override
  State<LocationSelector> createState() => _LocationSelectorState();
}

class _LocationSelectorState extends State<LocationSelector> {
  final List<Map<String, dynamic>> _algeriaData = [];
  List<String> _baladiyat = [];

  @override
  void initState() {
    super.initState();
    _loadAlgeriaData();
  }

  Future<void> _loadAlgeriaData() async {
    final data = await DefaultAssetBundle.of(context)
        .loadString('assets/data/algeria_regions.json');
    final jsonData = jsonDecode(data) as List;
    
    setState(() {
      _algeriaData.addAll(jsonData.cast<Map<String, dynamic>>());
    });

    if (widget.selectedWilaya != null) {
      _updateBaladiyat(widget.selectedWilaya!);
    }
  }

  void _updateBaladiyat(String wilayaName) {
    final wilaya = _algeriaData.firstWhere(
      (w) => w['name'] == wilayaName,
      orElse: () => {},
    );
    
    setState(() {
      _baladiyat = List<String>.from(wilaya['baladiyat'] ?? []);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // اختيار الولاية
        DropdownButtonFormField<String>(
          value: widget.selectedWilaya,
          onChanged: widget.enabled ? (value) {
            widget.onWilayaChanged(value);
            if (value != null) {
              _updateBaladiyat(value);
              widget.onBaladiyaChanged(null);
            }
          } : null,
          decoration: InputDecoration(
            labelText: 'الولاية',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          ),
          items: _algeriaData.map((wilaya) {
            return DropdownMenuItem(
              value: wilaya['name'],
              child: Text(wilaya['name']),
            );
          }).toList(),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'يرجى اختيار الولاية';
            }
            return null;
          },
        ),
        const SizedBox(height: 16),

        // اختيار البلدية
        DropdownButtonFormField<String>(
          value: widget.selectedBaladiya,
          onChanged: widget.enabled && widget.selectedWilaya != null
              ? widget.onBaladiyaChanged
              : null,
          decoration: InputDecoration(
            labelText: 'البلدية',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          ),
          items: _baladiyat.map((baladiya) {
            return DropdownMenuItem(
              value: baladiya,
              child: Text(baladiya),
            );
          }).toList(),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'يرجى اختيار البلدية';
            }
            return null;
          },
        ),
      ],
    );
  }
}