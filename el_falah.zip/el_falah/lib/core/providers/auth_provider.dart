// lib/core/providers/auth_provider.dart
final authServiceProvider = Provider<AuthService>((ref) {
  return AuthService();
});

final authStateProvider = StreamProvider<UserModel?>((ref) {
  final authService = ref.watch(authServiceProvider);
  return authService.userStream;
});

final authNotifierProvider = StateNotifierProvider<AuthNotifier, AuthState>(
  (ref) => AuthNotifier(ref),
);

class AuthNotifier extends StateNotifier<AuthState> {
  final Ref ref;

  AuthNotifier(this.ref) : super(const AuthState.initial()) {
    _init();
  }

  void _init() {
    ref.listen<AsyncValue<UserModel?>>(
      authStateProvider,
      (previous, next) {
        next.when(
          data: (user) {
            state = user != null 
              ? AuthState.authenticated(user)
              : const AuthState.unauthenticated();
          },
          loading: () => state = const AuthState.loading(),
          error: (error, stack) => state = AuthState.error(error.toString()),
        );
      },
    );
  }

  Future<void> signUp({
    required String email,
    required String password,
    required String fullName,
    required String phone,
    required UserType userType,
    required String wilaya,
    required String baladiya,
    File? profileImage,
  }) async {
    state = const AuthState.loading();
    try {
      final authService = ref.read(authServiceProvider);
      final user = await authService.signUp(
        email: email,
        password: password,
        fullName: fullName,
        phone: phone,
        userType: userType,
        wilaya: wilaya,
        baladiya: baladiya,
        profileImage: profileImage,
      );
      state = AuthState.authenticated(user);
    } catch (e) {
      state = AuthState.error(e.toString());
      rethrow;
    }
  }

  Future<void> signIn({
    required String email,
    required String password,
  }) async {
    state = const AuthState.loading();
    try {
      final authService = ref.read(authServiceProvider);
      final user = await authService.signIn(
        email: email,
        password: password,
      );
      state = AuthState.authenticated(user);
    } catch (e) {
      state = AuthState.error(e.toString());
      rethrow;
    }
  }

  Future<void> signOut() async {
    state = const AuthState.loading();
    try {
      final authService = ref.read(authServiceProvider);
      await authService.signOut();
      state = const AuthState.unauthenticated();
    } catch (e) {
      state = AuthState.error(e.toString());
      rethrow;
    }
  }

  Future<void> resetPassword(String email) async {
    try {
      final authService = ref.read(authServiceProvider);
      await authService.resetPassword(email);
    } catch (e) {
      rethrow;
    }
  }
}

@immutable
class AuthState {
  final UserModel? user;
  final bool isLoading;
  final String? error;

  const AuthState({
    this.user,
    this.isLoading = false,
    this.error,
  });

  const AuthState.initial()
      : user = null,
        isLoading = false,
        error = null;

  const AuthState.loading()
      : user = null,
        isLoading = true,
        error = null;

  const AuthState.unauthenticated()
      : user = null,
        isLoading = false,
        error = null;

  const AuthState.authenticated(UserModel user)
      : user = user,
        isLoading = false,
        error = null;

  const AuthState.error(String error)
      : user = null,
        isLoading = false,
        error = error;

  bool get isAuthenticated => user != null;
  bool get isNotAuthenticated => user == null;
  bool get hasError => error != null;

  AuthState copyWith({
    UserModel? user,
    bool? isLoading,
    String? error,
  }) {
    return AuthState(
      user: user ?? this.user,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
    );
  }
}