// lib/core/services/storage_service.dart
class StorageService {
  final FirebaseStorage _storage = FirebaseStorage.instance;

  Future<String> uploadImage({
    required File image,
    required String path,
    int maxSizeKB = 500,
  }) async {
    try {
      // ضغط الصورة
      final compressedImage = await _compressImage(image, maxSizeKB);
      
      final ref = _storage.ref().child(path).child(Uuid().v4());
      final uploadTask = ref.putFile(compressedImage);
      final snapshot = await uploadTask;
      return await snapshot.ref.getDownloadURL();
    } catch (e) {
      throw Exception('فشل في رفع الصورة: $e');
    }
  }

  Future<File> _compressImage(File image, int maxSizeKB) async {
    final result = await FlutterImageCompress.compressAndGetFile(
      image.absolute.path,
      image.absolute.path + '_compressed.jpg',
      quality: 85,
      minWidth: 800,
      minHeight: 600,
    );
    return File(result!.path);
  }
}