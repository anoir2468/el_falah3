// lib/core/services/auth_service.dart
class AuthService {
  final FirebaseAuth _firebaseAuth;
  final FirebaseFirestore _firestore;
  final StorageService _storageService;

  AuthService({
    FirebaseAuth? firebaseAuth,
    FirebaseFirestore? firestore,
    StorageService? storageService,
  })  : _firebaseAuth = firebaseAuth ?? FirebaseAuth.instance,
        _firestore = firestore ?? FirebaseFirestore.instance,
        _storageService = storageService ?? StorageService();

  Stream<UserModel?> get userStream {
    return _firebaseAuth.authStateChanges().asyncMap((user) async {
      if (user == null || !user.emailVerified) return null;
      
      try {
        final userDoc = await _firestore.collection('users').doc(user.uid).get();
        if (userDoc.exists) {
          return UserModel.fromMap(userDoc.data()!);
        }
      } catch (e) {
        print('Error in user stream: $e');
      }
      return null;
    });
  }

  Future<UserModel> signUp({
    required String email,
    required String password,
    required String fullName,
    required String phone,
    required UserType userType,
    required String wilaya,
    required String baladiya,
    File? profileImage,
  }) async {
    try {
      // التحقق من وجود المستخدم مسبقاً
      final methods = await _firebaseAuth.fetchSignInMethodsForEmail(email);
      if (methods.isNotEmpty) {
        throw AuthException('هذا البريد الإلكتروني مستخدم بالفعل');
      }

      // إنشاء المستخدم
      final userCredential = await _firebaseAuth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );

      // رفع صورة الملف الشخصي إذا وجدت
      String? profileImageUrl;
      if (profileImage != null) {
        profileImageUrl = await _storageService.uploadImage(
          image: profileImage,
          path: 'profiles/${userCredential.user!.uid}',
        );
      }

      // إنشاء نموذج المستخدم
      final user = UserModel(
        uid: userCredential.user!.uid,
        email: email.trim(),
        fullName: fullName.trim(),
        phone: phone.trim(),
        userType: userType,
        wilaya: wilaya,
        baladiya: baladiya,
        createdAt: DateTime.now(),
        isEmailVerified: false,
        profileImage: profileImageUrl,
      );

      // حفظ في Firestore
      await _firestore
          .collection('users')
          .doc(userCredential.user!.uid)
          .set(user.toMap());

      // إرسال بريد التحقق
      await userCredential.user!.sendEmailVerification();

      return user;
    } on FirebaseAuthException catch (e) {
      throw AuthException(_getFirebaseAuthErrorMessage(e.code));
    } catch (e) {
      throw AuthException('حدث خطأ غير متوقع: $e');
    }
  }

  Future<UserModel> signIn({
    required String email,
    required String password,
  }) async {
    try {
      final userCredential = await _firebaseAuth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );

      if (!userCredential.user!.emailVerified) {
        await signOut();
        throw AuthException('يرجى التحقق من بريدك الإلكتروني أولاً');
      }

      final userDoc = await _firestore
          .collection('users')
          .doc(userCredential.user!.uid)
          .get();

      if (!userDoc.exists) {
        await signOut();
        throw AuthException('بيانات المستخدم غير موجودة');
      }

      return UserModel.fromMap(userDoc.data()!);
    } on FirebaseAuthException catch (e) {
      throw AuthException(_getFirebaseAuthErrorMessage(e.code));
    }
  }

  Future<void> signOut() async {
    await _firebaseAuth.signOut();
  }

  Future<void> resetPassword(String email) async {
    try {
      await _firebaseAuth.sendPasswordResetEmail(email: email.trim());
    } on FirebaseAuthException catch (e) {
      throw AuthException(_getFirebaseAuthErrorMessage(e.code));
    }
  }

  Future<void> updateProfile({
    required String uid,
    String? fullName,
    String? phone,
    String? wilaya,
    String? baladiya,
    String? bio,
    File? profileImage,
  }) async {
    try {
      final userDoc = _firestore.collection('users').doc(uid);
      final updates = <String, dynamic>{};

      if (fullName != null) updates['fullName'] = fullName.trim();
      if (phone != null) updates['phone'] = phone.trim();
      if (wilaya != null) updates['wilaya'] = wilaya;
      if (baladiya != null) updates['baladiya'] = baladiya;
      if (bio != null) updates['bio'] = bio.trim();

      // رفع صورة جديدة إذا وجدت
      if (profileImage != null) {
        final imageUrl = await _storageService.uploadImage(
          image: profileImage,
          path: 'profiles/$uid',
        );
        updates['profileImage'] = imageUrl;
      }

      updates['updatedAt'] = FieldValue.serverTimestamp();

      await userDoc.update(updates);
    } catch (e) {
      throw AuthException('فشل في تحديث الملف الشخصي: $e');
    }
  }

  String _getFirebaseAuthErrorMessage(String code) {
    switch (code) {
      case 'email-already-in-use':
        return 'هذا البريد الإلكتروني مستخدم بالفعل';
      case 'invalid-email':
        return 'البريد الإلكتروني غير صحيح';
      case 'operation-not-allowed':
        return 'عملية التسجيل غير مسموحة';
      case 'weak-password':
        return 'كلمة المرور ضعيفة، يجب أن تكون 6 أحرف على الأقل';
      case 'user-disabled':
        return 'هذا الحساب موقوف';
      case 'user-not-found':
        return 'لا يوجد حساب مرتبط بهذا البريد';
      case 'wrong-password':
        return 'كلمة المرور غير صحيحة';
      case 'too-many-requests':
        return 'محاولات كثيرة جداً، يرجى المحاولة لاحقاً';
      default:
        return 'حدث خطأ غير متوقع';
    }
  }
}

class AuthException implements Exception {
  final String message;
  AuthException(this.message);

  @override
  String toString() => message;
}