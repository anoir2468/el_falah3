// lib/core/utils/progress_tracker.dart
class ProgressTracker {
  static final Map<String, bool> _tasks = {
    'auth': false,
    'home': false,
    'equipment': false,
    'workers': false,
    'land': false,
    'supplies': false,
    'training': false,
    'profile': false,
  };

  static void markComplete(String task) => _tasks[task] = true;
  static double get progress => _tasks.values.where((v) => v).length / _tasks.length;
}