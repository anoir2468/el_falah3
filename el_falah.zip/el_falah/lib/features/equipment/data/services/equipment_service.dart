// lib/features/equipment/data/services/equipment_service.dart
class EquipmentService {
  final FirebaseFirestore _firestore;
  final StorageService _storageService;

  EquipmentService({
    FirebaseFirestore? firestore,
    StorageService? storageService,
  })  : _firestore = firestore ?? FirebaseFirestore.instance,
        _storageService = storageService ?? StorageService();

  Stream<List<EquipmentEntity>> getEquipmentList({
    String? wilaya,
    EquipmentType? type,
    double? minPrice,
    double? maxPrice,
    EquipmentCondition? condition,
  }) {
    var query = _firestore
        .collection('equipment')
        .where('isAvailable', isEqualTo: true)
        .orderBy('createdAt', descending: true);

    if (wilaya != null) {
      query = query.where('wilaya', isEqualTo: wilaya);
    }
    if (type != null) {
      query = query.where('type', isEqualTo: type.name);
    }
    if (minPrice != null) {
      query = query.where('price', isGreaterThanOrEqualTo: minPrice);
    }
    if (maxPrice != null) {
      query = query.where('price', isLessThanOrEqualTo: maxPrice);
    }
    if (condition != null) {
      query = query.where('condition', isEqualTo: condition.name);
    }

    return query.snapshots().map((snapshot) {
      return snapshot.docs
          .map((doc) => EquipmentEntity.fromMap(doc.data()))
          .toList();
    });
  }

  Stream<EquipmentEntity> getEquipment(String id) {
    return _firestore
        .collection('equipment')
        .doc(id)
        .snapshots()
        .map((snapshot) => EquipmentEntity.fromMap(snapshot.data()!));
  }

  Future<String> addEquipment(EquipmentEntity equipment) async {
    try {
      // رفع الصور إلى التخزين
      final List<String> imageUrls = [];
      for (final imageFile in equipment.images.cast<File>()) {
        final url = await _storageService.uploadImage(
          image: imageFile,
          path: 'equipment/${equipment.id}',
        );
        imageUrls.add(url);
      }

      // تحديث الكيان بروابط الصور
      final equipmentWithUrls = equipment.copyWith(images: imageUrls);

      // حفظ في Firestore
      await _firestore
          .collection('equipment')
          .doc(equipment.id)
          .set(equipmentWithUrls.toMap());

      return equipment.id;
    } catch (e) {
      throw Exception('فشل في إضافة المعدة: $e');
    }
  }

  Future<void> updateEquipment(EquipmentEntity equipment) async {
    try {
      await _firestore
          .collection('equipment')
          .doc(equipment.id)
          .update(equipment.toMap());
    } catch (e) {
      throw Exception('فشل في تحديث المعدة: $e');
    }
  }

  Future<void> deleteEquipment(String id) async {
    try {
      await _firestore
          .collection('equipment')
          .doc(id)
          .update({'isAvailable': false});
    } catch (e) {
      throw Exception('فشل في حذف المعدة: $e');
    }
  }

  Future<void> incrementViewCount(String id) async {
    try {
      await _firestore
          .collection('equipment')
          .doc(id)
          .update({'viewCount': FieldValue.increment(1)});
    } catch (e) {
      print('فشل في زيادة عدد المشاهدات: $e');
    }
  }

  Stream<List<EquipmentEntity>> getUserEquipment(String userId) {
    return _firestore
        .collection('equipment')
        .where('ownerId', isEqualTo: userId)
        .where('isAvailable', isEqualTo: true)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs
          .map((doc) => EquipmentEntity.fromMap(doc.data()))
          .toList();
    });
  }
}