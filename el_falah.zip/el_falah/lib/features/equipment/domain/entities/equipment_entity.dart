// lib/features/equipment/domain/entities/equipment_entity.dart

import 'package:cloud_firestore/cloud_firestore.dart';

class EquipmentEntity {
  final String id;
  final String title;
  final String description;
  final double price;
  final EquipmentType type;
  final EquipmentCondition condition;
  final List<String> images;
  final String wilaya;
  final String baladiya;
  final String ownerId;
  final DateTime createdAt;
  final DateTime? updatedAt;
  final bool isAvailable;
  final int viewCount;

  EquipmentEntity({
    required this.id,
    required this.title,
    required this.description,
    required this.price,
    required this.type,
    required this.condition,
    required this.images,
    required this.wilaya,
    required this.baladiya,
    required this.ownerId,
    required this.createdAt,
    this.updatedAt,
    this.isAvailable = true,
    this.viewCount = 0,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'price': price,
      'type': type.name,
      'condition': condition.name,
      'images': images,
      'wilaya': wilaya,
      'baladiya': baladiya,
      'ownerId': ownerId,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': updatedAt != null ? Timestamp.fromDate(updatedAt!) : null,
      'isAvailable': isAvailable,
      'viewCount': viewCount,
    };
  }

  factory EquipmentEntity.fromMap(Map<String, dynamic> map) {
    return EquipmentEntity(
      id: map['id'],
      title: map['title'],
      description: map['description'],
      price: map['price'].toDouble(),
      type: EquipmentType.values.firstWhere((e) => e.name == map['type']),
      condition: EquipmentCondition.values.firstWhere((e) => e.name == map['condition']),
      images: List<String>.from(map['images']),
      wilaya: map['wilaya'],
      baladiya: map['baladiya'],
      ownerId: map['ownerId'],
      createdAt: (map['createdAt'] as Timestamp).toDate(),
      updatedAt: map['updatedAt'] != null ? (map['updatedAt'] as Timestamp).toDate() : null,
      isAvailable: map['isAvailable'],
      viewCount: map['viewCount'],
    );
  }
}

enum EquipmentType {
  tractor('جرار'),
  harvester('حاصد'),
  plow('محراث'),
  sprayer('مرش'),
  other('أخرى');

  const EquipmentType(this.arName);
  final String arName;
}

enum EquipmentCondition {
  newCondition('جديد'),
  used('مستعمل'),
  needsRepair('يحتاج إصلاح');

  const EquipmentCondition(this.arName);
  final String arName;
}