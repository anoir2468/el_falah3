// lib/features/equipment/presentation/providers/equipment_provider.dart
final equipmentServiceProvider = Provider<EquipmentService>((ref) {
  return EquipmentService();
});

final equipmentListProvider = StreamProvider.autoDispose
    .family<List<EquipmentEntity>, EquipmentFilter>(
  (ref, filter) {
    final equipmentService = ref.watch(equipmentServiceProvider);
    return equipmentService.getEquipmentList(
      wilaya: filter.wilaya,
      type: filter.type,
      minPrice: filter.minPrice,
      maxPrice: filter.maxPrice,
      condition: filter.condition,
    );
  },
);

final equipmentProvider = StreamProvider.autoDispose
    .family<EquipmentEntity, String>((ref, id) {
  final equipmentService = ref.watch(equipmentServiceProvider);
  return equipmentService.getEquipment(id);
});

final userEquipmentProvider = StreamProvider.autoDispose
    .family<List<EquipmentEntity>, String>((ref, userId) {
  final equipmentService = ref.watch(equipmentServiceProvider);
  return equipmentService.getUserEquipment(userId);
});

final equipmentFilterProvider =
    StateNotifierProvider<EquipmentFilterNotifier, EquipmentFilter>(
  (ref) => EquipmentFilterNotifier(),
);

class EquipmentFilterNotifier extends StateNotifier<EquipmentFilter> {
  EquipmentFilterNotifier()
      : super(const EquipmentFilter());

  void setWilaya(String? wilaya) {
    state = state.copyWith(wilaya: wilaya);
  }

  void setType(EquipmentType? type) {
    state = state.copyWith(type: type);
  }

  void setPriceRange(double? minPrice, double? maxPrice) {
    state = state.copyWith(minPrice: minPrice, maxPrice: maxPrice);
  }

  void setCondition(EquipmentCondition? condition) {
    state = state.copyWith(condition: condition);
  }

  void reset() {
    state = const EquipmentFilter();
  }
}

@immutable
class EquipmentFilter {
  final String? wilaya;
  final EquipmentType? type;
  final double? minPrice;
  final double? maxPrice;
  final EquipmentCondition? condition;

  const EquipmentFilter({
    this.wilaya,
    this.type,
    this.minPrice,
    this.maxPrice,
    this.condition,
  });

  EquipmentFilter copyWith({
    String? wilaya,
    EquipmentType? type,
    double? minPrice,
    double? maxPrice,
    EquipmentCondition? condition,
  }) {
    return EquipmentFilter(
      wilaya: wilaya ?? this.wilaya,
      type: type ?? this.type,
      minPrice: minPrice ?? this.minPrice,
      maxPrice: maxPrice ?? this.maxPrice,
      condition: condition ?? this.condition,
    );
  }

  bool get hasFilters {
    return wilaya != null ||
        type != null ||
        minPrice != null ||
        maxPrice != null ||
        condition != null;
  }
}