// lib/features/equipment/presentation/pages/add_equipment_page.dart
class AddEquipmentPage extends ConsumerStatefulWidget {
  const AddEquipmentPage({super.key});

  @override
  ConsumerState<AddEquipmentPage> createState() => _AddEquipmentPageState();
}

class _AddEquipmentPageState extends ConsumerState<AddEquipmentPage> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _priceController = TextEditingController();
  final _brandController = TextEditingController();
  final _yearController = TextEditingController();
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();
  final _featuresController = TextEditingController();

  EquipmentType _selectedType = EquipmentType.tractor;
  EquipmentCondition _selectedCondition = EquipmentCondition.used;
  String? _selectedWilaya;
  String? _selectedBaladiya;
  List<File> _images = [];
  bool _hasInsurance = false;
  bool _isLoading = false;
  final List<String> _features = [];

  @override
  void initState() {
    super.initState();
    _initializeUserData();
  }

  void _initializeUserData() {
    final user = ref.read(authStateProvider).value;
    if (user != null) {
      _phoneController.text = user.phone;
      _emailController.text = user.email;
      _selectedWilaya = user.wilaya;
      _selectedBaladiya = user.baladiya;
    }
  }

  Future<void> _pickImages() async {
    try {
      final List<XFile> pickedFiles = await ImagePicker().pickMultiImage(
        maxWidth: 1200,
        maxHeight: 1200,
        imageQuality: 80,
      );

      if (pickedFiles.isNotEmpty) {
        setState(() {
          _images.addAll(pickedFiles.map((file) => File(file.path)));
        });
      }
    } catch (e) {
      _showErrorDialog('فشل في اختيار الصور: $e');
    }
  }

  void _removeImage(int index) {
    setState(() {
      _images.removeAt(index);
    });
  }

  void _addFeature() {
    final feature = _featuresController.text.trim();
    if (feature.isNotEmpty && !_features.contains(feature)) {
      setState(() {
        _features.add(feature);
        _featuresController.clear();
      });
    }
  }

  void _removeFeature(String feature) {
    setState(() {
      _features.remove(feature);
    });
  }

  Future<void> _submitEquipment() async {
    if (!_formKey.currentState!.validate()) return;
    if (_images.isEmpty) {
      _showErrorDialog('يرجى إضافة صورة واحدة على الأقل');
      return;
    }
    if (_selectedWilaya == null || _selectedBaladiya == null) {
      _showErrorDialog('يرجى اختيار الولاية والبلدية');
      return;
    }

    FocusScope.of(context).unfocus();
    setState(() => _isLoading = true);

    try {
      final user = ref.read(authStateProvider).value;
      if (user == null) throw Exception('يجب تسجيل الدخول أولاً');

      final equipment = EquipmentEntity(
        id: const Uuid().v4(),
        title: _titleController.text.trim(),
        description: _descriptionController.text.trim(),
        price: double.parse(_priceController.text),
        type: _selectedType,
        condition: _selectedCondition,
        images: _images,
        wilaya: _selectedWilaya!,
        baladiya: _selectedBaladiya!,
        ownerId: user.uid,
        createdAt: DateTime.now(),
        contactPhone: _phoneController.text.trim(),
        contactEmail: _emailController.text.trim(),
        brand: _brandController.text.trim().isEmpty ? null : _brandController.text.trim(),
        manufacturingYear: _yearController.text.trim().isEmpty ? null : int.parse(_yearController.text),
        hasInsurance: _hasInsurance,
        features: _features,
      );

      final equipmentService = ref.read(equipmentServiceProvider);
      await equipmentService.addEquipment(equipment);

      _showSuccessDialog();
    } catch (e) {
      _showErrorDialog('فشل في إضافة المعدة: $e');
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green),
            SizedBox(width: 8),
            Text('تم الإضافة بنجاح'),
          ],
        ),
        content: const Text('تم إضافة المعدة بنجاح وسيتم عرضها في القائمة'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              context.go('/equipment');
            },
            child: const Text('عرض القائمة'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _resetForm();
            },
            child: const Text('إضافة أخرى'),
          ),
        ],
      ),
    );
  }

  void _resetForm() {
    _formKey.currentState?.reset();
    _titleController.clear();
    _descriptionController.clear();
    _priceController.clear();
    _brandController.clear();
    _yearController.clear();
    _featuresController.clear();
    setState(() {
      _images.clear();
      _features.clear();
      _selectedType = EquipmentType.tractor;
      _selectedCondition = EquipmentCondition.used;
      _hasInsurance = false;
      _initializeUserData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('إضافة معدة جديدة'),
        actions: [
          if (_images.isNotEmpty || _features.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.refresh),
              onPressed: _resetForm,
              tooltip: 'إعادة تعيين',
            ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // معرض الصور
            _buildImageGallery(),
            const SizedBox(height: 24),

            // المعلومات الأساسية
            _buildBasicInfoSection(),
            const SizedBox(height: 24),

            // المواصفات
            _buildSpecificationsSection(),
            const SizedBox(height: 24),

            // الموقع
            _buildLocationSection(),
            const SizedBox(height: 24),

            // معلومات الاتصال
            _buildContactSection(),
            const SizedBox(height: 24),

            // المميزات
            _buildFeaturesSection(),
            const SizedBox(height: 32),

            // زر الإضافة
            _buildSubmitButton(),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _buildImageGallery() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'صور المعدة *',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
            color: Colors.grey[700],
          ),
        ),
        const SizedBox(height: 8),
        if (_images.isEmpty)
          Container(
            width: double.infinity,
            height: 150,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey[300]!),
              borderRadius: BorderRadius.circular(12),
              color: Colors.grey[50],
            ),
            child: InkWell(
              onTap: _pickImages,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.camera_alt, size: 40, color: Colors.grey[400]),
                  const SizedBox(height: 8),
                  Text(
                    'إضافة صور المعدة',
                    style: TextStyle(color: Colors.grey[600]),
                  ),
                  Text(
                    '(3-10 صور)',
                    style: TextStyle(color: Colors.grey[500], fontSize: 12),
                  ),
                ],
              ),
            ),
          )
        else
          Column(
            children: [
              SizedBox(
                height: 120,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: _images.length,
                  itemBuilder: (context, index) {
                    return Stack(
                      children: [
                        Container(
                          width: 120,
                          height: 120,
                          margin: const EdgeInsets.only(right: 8),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            color: Colors.grey[200],
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.file(
                              _images[index],
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        Positioned(
                          top: 4,
                          right: 4,
                          child: CircleAvatar(
                            radius: 12,
                            backgroundColor: Colors.red,
                            child: IconButton(
                              icon: const Icon(Icons.close, size: 12, color: Colors.white),
                              onPressed: () => _removeImage(index),
                              padding: EdgeInsets.zero,
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
              const SizedBox(height: 8),
              if (_images.length < 10)
                OutlinedButton.icon(
                  onPressed: _pickImages,
                  icon: const Icon(Icons.add),
                  label: const Text('إضافة المزيد من الصور'),
                ),
            ],
          ),
      ],
    );
  }

  Widget _buildBasicInfoSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'المعلومات الأساسية',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
            color: Colors.grey[700],
          ),
        ),
        const SizedBox(height: 16),
        AuthTextField(
          controller: _titleController,
          label: 'اسم المعدة *',
          hintText: 'مثال: جرار زراعي John Deere',
          prefixIcon: Icons.agriculture,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'يرجى إدخال اسم المعدة';
            }
            if (value.length < 5) {
              return 'اسم المعدة يجب أن يكون 5 أحرف على الأقل';
            }
            return null;
          },
        ),
        const SizedBox(height: 16),
        AuthTextField(
          controller: _descriptionController,
          label: 'الوصف التفصيلي *',
          hintText: 'وصف كامل للمعدة ومواصفاتها...',
          prefixIcon: Icons.description,
          maxLines: 4,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'يرجى إدخال وصف المعدة';
            }
            if (value.length < 20) {
              return 'الوصف يجب أن يكون 20 حرف على الأقل';
            }
            return null;
          },
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: AuthTextField(
                controller: _priceController,
                label: 'السعر (د.ج) *',
                hintText: '0.00',
                prefixIcon: Icons.attach_money,
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'يرجى إدخال السعر';
                  }
                  if (double.tryParse(value) == null) {
                    return 'يرجى إدخال سعر صحيح';
                  }
                  if (double.parse(value) <= 0) {
                    return 'السعر يجب أن يكون أكبر من الصفر';
                  }
                  return null;
                },
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'نوع المعدة *',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<EquipmentType>(
                    value: _selectedType,
                    onChanged: (value) {
                      setState(() {
                        _selectedType = value!;
                      });
                    },
                    items: EquipmentType.values.map((type) {
                      return DropdownMenuItem(
                        value: type,
                        child: Text(type.arName),
                      );
                    }).toList(),
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSpecificationsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'المواصفات الفنية',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
            color: Colors.grey[700],
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'الحالة *',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<EquipmentCondition>(
                    value: _selectedCondition,
                    onChanged: (value) {
                      setState(() {
                        _selectedCondition = value!;
                      });
                    },
                    items: EquipmentCondition.values.map((condition) {
                      return DropdownMenuItem(
                        value: condition,
                        child: Text(condition.arName),
                      );
                    }).toList(),
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: AuthTextField(
                controller: _brandController,
                label: 'الماركة',
                hintText: 'مثال: John Deere',
                prefixIcon: Icons.business_center,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        AuthTextField(
          controller: _yearController,
          label: 'سنة الصنع',
          hintText: 'مثال: 2023',
          prefixIcon: Icons.calendar_today,
          keyboardType: TextInputType.number,
          validator: (value) {
            if (value != null && value.isNotEmpty) {
              final year = int.tryParse(value);
              if (year == null || year < 1900 || year > DateTime.now().year) {
                return 'يرجى إدخال سنة صحيحة';
              }
            }
            return null;
          },
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Checkbox(
              value: _hasInsurance,
              onChanged: (value) {
                setState(() {
                  _hasInsurance = value ?? false;
                });
              },
            ),
            const Text('الجهة مؤمنة'),
          ],
        ),
      ],
    );
  }

  Widget _buildLocationSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'الموقع',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
            color: Colors.grey[700],
          ),
        ),
        const SizedBox(height: 16),
        LocationSelector(
          selectedWilaya: _selectedWilaya,
          selectedBaladiya: _selectedBaladiya,
          onWilayaChanged: (value) {
            setState(() {
              _selectedWilaya = value;
              _selectedBaladiya = null;
            });
          },
          onBaladiyaChanged: (value) {
            setState(() {
              _selectedBaladiya = value;
            });
          },
        ),
      ],
    );
  }

  Widget _buildContactSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'معلومات الاتصال',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
            color: Colors.grey[700],
          ),
        ),
        const SizedBox(height: 16),
        AuthTextField(
          controller: _phoneController,
          label: 'رقم الهاتف *',
          hintText: 'أدخل رقم الهاتف للتواصل',
          prefixIcon: Icons.phone,
          keyboardType: TextInputType.phone,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'يرجى إدخال رقم الهاتف';
            }
            if (!RegExp(r'^(\+213|0)(5|6|7)[0-9]{8}$').hasMatch(value)) {
              return 'يرجى إدخال رقم هاتف جزائري صحيح';
            }
            return null;
          },
        ),
        const SizedBox(height: 16),
        AuthTextField(
          controller: _emailController,
          label: 'البريد الإلكتروني',
          hintText: 'البريد الإلكتروني (اختياري)',
          prefixIcon: Icons.email,
          keyboardType: TextInputType.emailAddress,
          validator: (value) {
            if (value != null && value.isNotEmpty && !EmailValidator.validate(value)) {
              return 'يرجى إدخال بريد إلكتروني صحيح';
            }
            return null;
          },
        ),
      ],
    );
  }

  Widget _buildFeaturesSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'المميزات الإضافية',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
            color: Colors.grey[700],
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: AuthTextField(
                controller: _featuresController,
                label: 'إضافة ميزة جديدة',
                hintText: 'أدخل ميزة جديدة...',
                prefixIcon: Icons.add,
              ),
            ),
            const SizedBox(width: 8),
            ElevatedButton(
              onPressed: _addFeature,
              style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              ),
              child: const Text('إضافة'),
            ),
          ],
        ),
        if (_features.isNotEmpty) ...[
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _features.map((feature) {
              return Chip(
                label: Text(feature),
                onDeleted: () => _removeFeature(feature),
                deleteIcon: const Icon(Icons.close, size: 16),
              );
            }).toList(),
          ),
        ],
      ],
    );
  }

  Widget _buildSubmitButton() {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: _isLoading ? null : _submitEquipment,
        style: ElevatedButton.styleFrom(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        child: _isLoading
            ? const SizedBox(
                height: 20,
                width: 20,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor: AlwaysStoppedAnimation(Colors.white),
                ),
              )
            : const Text(
                'إضافة المعدة',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
      ),
    );
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.error_outline, color: Colors.red),
            SizedBox(width: 8),
            Text('خطأ'),
          ],
        ),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('حسناً'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _priceController.dispose();
    _brandController.dispose();
    _yearController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _featuresController.dispose();
    super.dispose();
  }
}