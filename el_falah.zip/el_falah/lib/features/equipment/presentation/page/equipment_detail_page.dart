// lib/features/equipment/presentation/pages/equipment_detail_page.dart
class EquipmentDetailPage extends ConsumerStatefulWidget {
  final String id;

  const EquipmentDetailPage({super.key, required this.id});

  @override
  ConsumerState<EquipmentDetailPage> createState() => _EquipmentDetailPageState();
}

class _EquipmentDetailPageState extends ConsumerState<EquipmentDetailPage> {
  final PageController _pageController = PageController();
  int _currentImageIndex = 0;
  bool _isContactExpanded = false;

  @override
  void initState() {
    super.initState();
    _incrementViewCount();
  }

  void _incrementViewCount() {
    final equipmentService = ref.read(equipmentServiceProvider);
    equipmentService.incrementViewCount(widget.id);
  }

  void _contactOwner(EquipmentEntity equipment) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => ContactOwnerSheet(equipment: equipment),
    );
  }

  void _shareEquipment(EquipmentEntity equipment) {
    final shareText = '''
${equipment.title}

${equipment.description}

السعر: ${equipment.price} د.ج
الموقع: ${equipment.wilaya} - ${equipment.baladiya}

اطلع على التفاصيل في تطبيق منصة الفلاح الجزائري
''';

    Share.share(shareText);
  }

  @override
  Widget build(BuildContext context) {
    final equipmentAsync = ref.watch(equipmentProvider(widget.id));

    return Scaffold(
      body: equipmentAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stack) => Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, size: 64, color: Colors.grey),
              const SizedBox(height: 16),
              const Text('حدث خطأ في تحميل البيانات'),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () => ref.refresh(equipmentProvider(widget.id)),
                child: const Text('إعادة المحاولة'),
              ),
            ],
          ),
        ),
        data: (equipment) => _buildEquipmentDetail(equipment),
      ),
    );
  }

  Widget _buildEquipmentDetail(EquipmentEntity equipment) {
    final currentUser = ref.watch(authStateProvider).value;
    final isOwner = currentUser?.uid == equipment.ownerId;

    return CustomScrollView(
      slivers: [
        SliverAppBar(
          expandedHeight: 300,
          flexibleSpace: _buildImageGallery(equipment),
          actions: [
            IconButton(
              icon: const Icon(Icons.share),
              onPressed: () => _shareEquipment(equipment),
            ),
            if (isOwner)
              PopupMenuButton(
                itemBuilder: (context) => [
                  const PopupMenuItem(
                    value: 'edit',
                    child: Row(
                      children: [
                        Icon(Icons.edit),
                        SizedBox(width: 8),
                        Text('تعديل'),
                      ],
                    ),
                  ),
                  const PopupMenuItem(
                    value: 'delete',
                    child: Row(
                      children: [
                        Icon(Icons.delete, color: Colors.red),
                        SizedBox(width: 8),
                        Text('حذف', style: TextStyle(color: Colors.red)),
                      ],
                    ),
                  ),
                ],
                onSelected: (value) {
                  if (value == 'edit') {
                    context.push('/equipment/${equipment.id}/edit');
                  } else if (value == 'delete') {
                    _deleteEquipment(equipment);
                  }
                },
              ),
          ],
        ),
        SliverList(
          delegate: SliverChildListDelegate([
            // المعلومات الأساسية
            _buildBasicInfo(equipment),
            const SizedBox(height: 24),

            // المواصفات
            _buildSpecifications(equipment),
            const SizedBox(height: 24),

            // الموقع
            _buildLocationInfo(equipment),
            const SizedBox(height: 24),

            // معلومات البائع
            _buildOwnerInfo(equipment),
            const SizedBox(height: 24),

            // أزرار التواصل
            if (!isOwner) _buildContactButtons(equipment),
            const SizedBox(height: 32),
          ]),
        ),
      ],
    );
  }

  Widget _buildImageGallery(EquipmentEntity equipment) {
    return Stack(
      children: [
        PageView.builder(
          controller: _pageController,
          itemCount: equipment.images.length,
          onPageChanged: (index) {
            setState(() {
              _currentImageIndex = index;
            });
          },
          itemBuilder: (context, index) {
            return Image.network(
              equipment.images[index],
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return Container(
                  color: Colors.grey[200],
                  child: const Icon(Icons.broken_image, size: 60, color: Colors.grey),
                );
              },
            );
          },
        ),
        if (equipment.images.length > 1)
          Positioned(
            bottom: 16,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ...List.generate(equipment.images.length, (index) {
                  return Container(
                    width: 8,
                    height: 8,
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _currentImageIndex == index
                          ? Colors.white
                          : Colors.white.withOpacity(0.5),
                    ),
                  );
                }),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildBasicInfo(EquipmentEntity equipment) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            equipment.title,
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            equipment.description,
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
              height: 1.5,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Text(
                '${equipment.price} د.ج',
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: _getConditionColor(equipment.condition),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  equipment.condition.arName,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSpecifications(EquipmentEntity equipment) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'المواصفات',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 16,
            runSpacing: 16,
            children: [
              _SpecificationItem(
                icon: Icons.agriculture,
                label: 'النوع',
                value: equipment.type.arName,
              ),
              if (equipment.brand != null)
                _SpecificationItem(
                  icon: Icons.business_center,
                  label: 'الماركة',
                  value: equipment.brand!,
                ),
              if (equipment.manufacturingYear != null)
                _SpecificationItem(
                  icon: Icons.calendar_today,
                  label: 'سنة الصنع',
                  value: equipment.manufacturingYear!.toString(),
                ),
              _SpecificationItem(
                icon: Icons.visibility,
                label: 'المشاهدات',
                value: equipment.viewCount.toString(),
              ),
              if (equipment.hasInsurance)
                _SpecificationItem(
                  icon: Icons.security,
                  label: 'التأمين',
                  value: 'مؤمن',
                ),
            ],
          ),
          if (equipment.features.isNotEmpty) ...[
            const SizedBox(height: 16),
            const Text(
              'المميزات:',
              style: TextStyle(fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: equipment.features.map((feature) {
                return Chip(
                  label: Text(feature),
                  backgroundColor: Colors.green[50],
                );
              }).toList(),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildLocationInfo(EquipmentEntity equipment) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'الموقع',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Icon(Icons.location_on, color: Theme.of(context).primaryColor),
              const SizedBox(width: 8),
              Text(
                '${equipment.wilaya} - ${equipment.baladiya}',
                style: const TextStyle(fontSize: 16),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            height: 200,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: Colors.grey[200],
            ),
            child: const Center(
              child: Icon(Icons.map, size: 50, color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOwnerInfo(EquipmentEntity equipment) {
    return FutureBuilder<DocumentSnapshot>(
      future: FirebaseFirestore.instance.collection('users').doc(equipment.ownerId).get(),
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }

        if (!snapshot.hasData || !snapshot.data!.exists) {
          return const SizedBox();
        }

        final ownerData = snapshot.data!.data() as Map<String, dynamic>;
        final owner = UserModel.fromMap(ownerData);

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'معلومات البائع',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              ListTile(
                leading: CircleAvatar(
                  radius: 25,
                  backgroundImage: owner.profileImage != null
                      ? NetworkImage(owner.profileImage!)
                      : null,
                  child: owner.profileImage == null
                      ? const Icon(Icons.person)
                      : null,
                ),
                title: Text(owner.fullName),
                subtitle: Text(owner.userType.arName),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.star, color: Colors.amber, size: 20),
                    const SizedBox(width: 4),
                    Text(owner.rating?.toStringAsFixed(1) ?? '0.0'),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildContactButtons(EquipmentEntity equipment) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => _contactOwner(equipment),
              icon: const Icon(Icons.phone),
              label: const Text('اتصال فوري'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () => _showContactDetails(equipment),
              icon: const Icon(Icons.contact_page),
              label: const Text('عرض معلومات الاتصال'),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showContactDetails(EquipmentEntity equipment) {
    setState(() {
      _isContactExpanded = !_isContactExpanded;
    });
  }

  void _deleteEquipment(EquipmentEntity equipment) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف المعدة'),
        content: const Text('هل أنت متأكد من حذف هذه المعدة؟ لا يمكن التراجع عن هذا الإجراء.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              try {
                final equipmentService = ref.read(equipmentServiceProvider);
                await equipmentService.deleteEquipment(equipment.id);
                if (mounted) {
                  Navigator.pop(context);
                }
              } catch (e) {
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('فشل في حذف المعدة: $e')),
                  );
                }
              }
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
  }

  Color _getConditionColor(EquipmentCondition condition) {
    switch (condition) {
      case EquipmentCondition.newCondition:
        return Colors.green;
      case EquipmentCondition.used:
        return Colors.orange;
      case EquipmentCondition.needsRepair:
        return Colors.red;
    }
  }
}

class _SpecificationItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _SpecificationItem({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey[200]!),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 20, color: Colors.grey[600]),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey[600],
                ),
              ),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class ContactOwnerSheet extends StatelessWidget {
  final EquipmentEntity equipment;

  const ContactOwnerSheet({super.key, required this.equipment});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'تواصل مع البائع',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          _ContactOption(
            icon: Icons.phone,
            title: 'اتصال هاتفي',
            subtitle: equipment.contactPhone,
            onTap: () => _makePhoneCall(equipment.contactPhone),
          ),
          const SizedBox(height: 12),
          if (equipment.contactEmail != null)
            _ContactOption(
              icon: Icons.email,
              title: 'بريد إلكتروني',
              subtitle: equipment.contactEmail!,
              onTap: () => _sendEmail(equipment.contactEmail!),
            ),
          const SizedBox(height: 12),
          _ContactOption(
            icon: Icons.message,
            title: 'رسالة نصية',
            subtitle: equipment.contactPhone,
            onTap: () => _sendSms(equipment.contactPhone),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إغلاق'),
            ),
          ),
        ],
      ),
    );
  }

  void _makePhoneCall(String phone) async {
    final url = 'tel:$phone';
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url));
    }
  }

  void _sendEmail(String email) async {
    final url = 'mailto:$email';
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url));
    }
  }

  void _sendSms(String phone) async {
    final url = 'sms:$phone';
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url));
    }
  }
}

class _ContactOption extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ContactOption({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: Theme.of(context).primaryColor.withOpacity(0.1),
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: Theme.of(context).primaryColor),
      ),
      title: Text(title),
      subtitle: Text(subtitle),
      onTap: onTap,
      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
    );
  }
}