// lib/features/equipment/presentation/pages/equipment_list_page.dart
class EquipmentListPage extends ConsumerWidget {
  const EquipmentListPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final filter = ref.watch(equipmentFilterProvider);
    final equipmentAsync = ref.watch(equipmentListProvider(filter));

    return Scaffold(
      appBar: AppBar(
        title: const Text('المعدات الزراعية'),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () => _showFilterDialog(context, ref),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Column(
        children: [
          // شريط البحث والفلاتر النشطة
          _buildActiveFilters(filter, ref),
          
          // قائمة المعدات
          Expanded(
            child: equipmentAsync.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (error, stack) => Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.error_outline, size: 64, color: Colors.grey),
                    const SizedBox(height: 16),
                    Text(
                      'حدث خطأ في تحميل البيانات',
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                    const SizedBox(height: 8),
                    TextButton(
                      onPressed: () => ref.refresh(equipmentListProvider(filter)),
                      child: const Text('إعادة المحاولة'),
                    ),
                  ],
                ),
              ),
              data: (equipmentList) {
                if (equipmentList.isEmpty) {
                  return _buildEmptyState(filter, context);
                }
                return _buildEquipmentList(equipmentList, context);
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          context.push('/equipment/add');
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildActiveFilters(EquipmentFilter filter, WidgetRef ref) {
    if (!filter.hasFilters) return const SizedBox();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      color: Colors.grey[50],
      child: Row(
        children: [
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  if (filter.wilaya != null)
                    _FilterChip(
                      label: 'الولاية: ${filter.wilaya}',
                      onDelete: () => ref
                          .read(equipmentFilterProvider.notifier)
                          .setWilaya(null),
                    ),
                  if (filter.type != null)
                    _FilterChip(
                      label: 'النوع: ${filter.type!.arName}',
                      onDelete: () => ref
                          .read(equipmentFilterProvider.notifier)
                          .setType(null),
                    ),
                  if (filter.minPrice != null || filter.maxPrice != null)
                    _FilterChip(
                      label: 'السعر: ${filter.minPrice ?? 0} - ${filter.maxPrice ?? '∞'}',
                      onDelete: () => ref
                          .read(equipmentFilterProvider.notifier)
                          .setPriceRange(null, null),
                    ),
                  if (filter.condition != null)
                    _FilterChip(
                      label: 'الحالة: ${filter.condition!.arName}',
                      onDelete: () => ref
                          .read(equipmentFilterProvider.notifier)
                          .setCondition(null),
                    ),
                ],
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              ref.read(equipmentFilterProvider.notifier).reset();
            },
            child: const Text('مسح الكل'),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState(EquipmentFilter filter, BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.agriculture,
            size: 80,
            color: Colors.grey[300],
          ),
          const SizedBox(height: 16),
          Text(
            filter.hasFilters ? 'لا توجد نتائج' : 'لا توجد معدات متاحة',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 8),
          Text(
            filter.hasFilters
                ? 'جرب تعديل عوامل التصفية للعثور على ما تبحث عنه'
                : 'كن أول من يضيف معدة زراعية',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Colors.grey[600],
                ),
          ),
          const SizedBox(height: 24),
          if (!filter.hasFilters)
            ElevatedButton(
              onPressed: () {
                context.push('/equipment/add');
              },
              child: const Text('إضافة معدة جديدة'),
            ),
        ],
      ),
    );
  }

  Widget _buildEquipmentList(List<EquipmentEntity> equipmentList, BuildContext context) {
    return ListView.builder(
      itemCount: equipmentList.length,
      itemBuilder: (context, index) {
        final equipment = equipmentList[index];
        return _EquipmentCard(equipment: equipment);
      },
    );
  }

  void _showFilterDialog(BuildContext context, WidgetRef ref) {
    final filter = ref.read(equipmentFilterProvider);
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تصفية النتائج'),
        content: SizedBox(
          width: double.maxFinite,
          child: _FilterDialogContent(filter: filter),
        ),
        actions: [
          TextButton(
            onPressed: () {
              ref.read(equipmentFilterProvider.notifier).reset();
              Navigator.pop(context);
            },
            child: const Text('إعادة التعيين'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('تطبيق'),
          ),
        ],
      ),
    );
  }
}

class _EquipmentCard extends ConsumerWidget {
  final EquipmentEntity equipment;

  const _EquipmentCard({required this.equipment});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: InkWell(
        onTap: () {
          context.push('/equipment/${equipment.id}');
          ref.read(equipmentServiceProvider).incrementViewCount(equipment.id);
        },
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // صورة المعدة
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.grey[200],
                ),
                child: equipment.images.isNotEmpty
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.network(
                          equipment.images.first,
                          fit: BoxFit.cover,
                        ),
                      )
                    : Icon(
                        Icons.agriculture,
                        size: 40,
                        color: Colors.grey[400],
                      ),
              ),
              const SizedBox(width: 16),

              // معلومات المعدة
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      equipment.title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      equipment.description,
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Icon(Icons.location_on, size: 14, color: Colors.grey[500]),
                        const SizedBox(width: 4),
                        Text(
                          '${equipment.wilaya} - ${equipment.baladiya}',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey[500],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '${equipment.price} د.ج',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.green,
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: _getConditionColor(equipment.condition),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            equipment.condition.arName,
                            style: const TextStyle(
                              fontSize: 12,
                              color: Colors.white,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getConditionColor(EquipmentCondition condition) {
    switch (condition) {
      case EquipmentCondition.newCondition:
        return Colors.green;
      case EquipmentCondition.used:
        return Colors.orange;
      case EquipmentCondition.needsRepair:
        return Colors.red;
    }
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final VoidCallback onDelete;

  const _FilterChip({
    required this.label,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      child: Chip(
        label: Text(label),
        onDeleted: onDelete,
        deleteIcon: const Icon(Icons.close, size: 16),
      ),
    );
  }
}