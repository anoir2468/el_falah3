// lib/features/profile/presentation/pages/profile_page.dart
class ProfilePage extends ConsumerWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userAsync = ref.watch(authStateProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('حسابي'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              // TODO: الانتقال إلى الإعدادات
            },
          ),
        ],
      ),
      body: userAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error:
            (error, stack) => Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error_outline, size: 64, color: Colors.grey),
                  const SizedBox(height: 16),
                  const Text('حدث خطأ في تحميل البيانات'),
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: () => ref.refresh(authStateProvider),
                    child: const Text('إعادة المحاولة'),
                  ),
                ],
              ),
            ),
        data: (user) {
          if (user == null) {
            return _buildNotLoggedInState();
          }
          return _buildProfileContent(user);
        },
      ),
    );
  }

  Widget _buildNotLoggedInState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.person_off, size: 80, color: Colors.grey),
          const SizedBox(height: 16),
          const Text(
            'غير مسجل الدخول',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            'يجب تسجيل الدخول لعرض الملف الشخصي',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: () {
              context.go('/auth/login');
            },
            child: const Text('تسجيل الدخول'),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileContent(UserModel user) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // رأس الملف الشخصي
          _buildProfileHeader(user),
          const SizedBox(height: 32),

          // الإحصائيات
          _buildStatsSection(user),
          const SizedBox(height: 24),

          // القائمة
          _buildMenuList(),
        ],
      ),
    );
  }

  Widget _buildProfileHeader(UserModel user) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // الصورة والمعلومات
            Row(
              children: [
                // صورة المستخدم
                Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.grey[300]!, width: 2),
                  ),
                  child: ClipOval(
                    child:
                        user.profileImage != null
                            ? Image.network(
                              user.profileImage!,
                              fit: BoxFit.cover,
                            )
                            : Icon(
                              Icons.person,
                              size: 40,
                              color: Colors.grey[400],
                            ),
                  ),
                ),
                const SizedBox(width: 16),

                // المعلومات
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        user.fullName,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        user.userType.arName,
                        style: TextStyle(fontSize: 16, color: Colors.grey[600]),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${user.wilaya} - ${user.baladiya}',
                        style: TextStyle(fontSize: 14, color: Colors.grey[500]),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(Icons.star, size: 16, color: Colors.amber),
                          const SizedBox(width: 4),
                          Text(
                            user.rating.toStringAsFixed(1),
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            '(${user.totalReviews} تقييم)',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey[500],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // الزر
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () {
                  context.push('/profile/edit');
                },
                icon: const Icon(Icons.edit),
                label: const Text('تعديل الملف الشخصي'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatsSection(UserModel user) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'إحصائياتي',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _StatItem(
                  value: '5',
                  label: 'المعدات',
                  icon: Icons.agriculture,
                ),
                _StatItem(value: '3', label: 'العمال', icon: Icons.engineering),
                _StatItem(value: '2', label: 'الأراضي', icon: Icons.landscape),
                _StatItem(value: '12', label: 'التقييمات', icon: Icons.star),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuList() {
    return Card(
      child: Column(
        children: [
          _ProfileMenuItem(
            icon: Icons.list_alt,
            title: 'إعلاناتي',
            onTap: () {
              // TODO: الانتقال إلى إعلاناتي
            },
          ),
          const Divider(height: 1),
          _ProfileMenuItem(
            icon: Icons.favorite,
            title: 'المفضلة',
            onTap: () {
              // TODO: الانتقال إلى المفضلة
            },
          ),
          const Divider(height: 1),
          _ProfileMenuItem(
            icon: Icons.notifications,
            title: 'الإشعارات',
            onTap: () {
              // TODO: الانتقال إلى الإشعارات
            },
          ),
          const Divider(height: 1),
          _ProfileMenuItem(
            icon: Icons.help,
            title: 'المساعدة والدعم',
            onTap: () {
              // TODO: الانتقال إلى المساعدة
            },
          ),
          const Divider(height: 1),
          _ProfileMenuItem(
            icon: Icons.info,
            title: 'عن التطبيق',
            onTap: () {
              // TODO: الانتقال إلى عن التطبيق
            },
          ),
          const Divider(height: 1),
          _ProfileMenuItem(
            icon: Icons.logout,
            title: 'تسجيل الخروج',
            color: Colors.red,
            onTap: _logout,
          ),
        ],
      ),
    );
  }

  void _logout() {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('تسجيل الخروج'),
            content: const Text('هل أنت متأكد من رغبتك في تسجيل الخروج؟'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('إلغاء'),
              ),
              TextButton(
                onPressed: () async {
                  Navigator.pop(context);
                  final authNotifier = ref.read(authNotifierProvider.notifier);
                  await authNotifier.signOut();
                },
                style: TextButton.styleFrom(foregroundColor: Colors.red),
                child: const Text('تسجيل الخروج'),
              ),
            ],
          ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final String value;
  final String label;
  final IconData icon;

  const _StatItem({
    required this.value,
    required this.label,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: Theme.of(context).primaryColor.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: Theme.of(context).primaryColor),
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
      ],
    );
  }
}

class _ProfileMenuItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;
  final Color? color;

  const _ProfileMenuItem({
    required this.icon,
    required this.title,
    required this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: color ?? Theme.of(context).primaryColor),
      title: Text(title, style: TextStyle(color: color)),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      onTap: onTap,
    );
  }
}
