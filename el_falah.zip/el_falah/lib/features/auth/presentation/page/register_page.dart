// lib/features/auth/presentation/pages/register_page.dart
class RegisterPage extends ConsumerStatefulWidget {
  const RegisterPage({super.key});

  @override
  ConsumerState<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends ConsumerState<RegisterPage> {
  final _formKey = GlobalKey<FormState>();
  final _fullNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final _phoneController = TextEditingController();

  UserType _selectedUserType = UserType.farmer;
  String? _selectedWilaya;
  String? _selectedBaladiya;
  File? _profileImage;
  bool _isLoading = false;
  bool _acceptTerms = false;

  final ImagePicker _imagePicker = ImagePicker();

  @override
  void dispose() {
    _fullNameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    try {
      final XFile? image = await _imagePicker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 800,
        maxHeight: 800,
        imageQuality: 80,
      );

      if (image != null) {
        setState(() {
          _profileImage = File(image.path);
        });
      }
    } catch (e) {
      _showErrorDialog('فشل في اختيار الصورة: $e');
    }
  }

  Future<void> _register() async {
    if (!_formKey.currentState!.validate()) return;
    if (!_acceptTerms) {
      _showErrorDialog('يرجى الموافقة على شروط الاستخدام أولاً');
      return;
    }
    if (_selectedWilaya == null || _selectedBaladiya == null) {
      _showErrorDialog('يرجى اختيار الولاية والبلدية');
      return;
    }

    FocusScope.of(context).unfocus();
    setState(() => _isLoading = true);

    try {
      await ref.read(authNotifierProvider.notifier).signUp(
        email: _emailController.text.trim(),
        password: _passwordController.text,
        fullName: _fullNameController.text.trim(),
        phone: _phoneController.text.trim(),
        userType: _selectedUserType,
        wilaya: _selectedWilaya!,
        baladiya: _selectedBaladiya!,
        profileImage: _profileImage,
      );

      // سيتم توجيه المستخدم تلقائياً بعد التسجيل الناجح
      _showSuccessDialog();
    } on AuthException catch (e) {
      _showErrorDialog(e.message);
    } catch (e) {
      _showErrorDialog('حدث خطأ غير متوقع أثناء التسجيل');
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green),
            SizedBox(width: 8),
            Text('تم التسجيل بنجاح'),
          ],
        ),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('مرحباً بك في منصة الفلاح الجزائري!'),
            SizedBox(height: 8),
            Text('يرجى التحقق من بريدك الإلكتروني لتفعيل الحساب.'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              context.go('/auth/login');
            },
            child: const Text('حسناً'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final size = MediaQuery.of(context).size;

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // زر الرجوع
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back),
                    padding: EdgeInsets.zero,
                    alignment: Alignment.centerLeft,
                  ),
                  const SizedBox(height: 20),

                  // العنوان
                  _buildHeaderSection(theme, size),
                  const SizedBox(height: 32),

                  // صورة الملف الشخصي
                  _buildProfileImageSection(),
                  const SizedBox(height: 32),

                  // حقول الإدخال
                  _buildInputFields(theme),
                  const SizedBox(height: 24),

                  // اختيار نوع المستخدم
                  _buildUserTypeSection(),
                  const SizedBox(height: 24),

                  // اختيار الموقع
                  _buildLocationSection(),
                  const SizedBox(height: 24),

                  // شروط الاستخدام
                  _buildTermsSection(),
                  const SizedBox(height: 32),

                  // زر التسجيل
                  _buildRegisterButton(),
                  const SizedBox(height: 24),

                  // رابط تسجيل الدخول
                  _buildLoginLink(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeaderSection(ThemeData theme, Size size) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Center(
          child: Container(
            width: size.width * 0.2,
            height: size.width * 0.2,
            decoration: BoxDecoration(
              color: theme.primaryColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(
              Icons.person_add,
              size: size.width * 0.1,
              color: theme.primaryColor,
            ),
          ),
        ),
        const SizedBox(height: 24),
        Text(
          'إنشاء حساب جديد',
          style: theme.textTheme.headlineMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'انضم إلى منصة الفلاح الجزائري وابدأ رحلتك',
          style: theme.textTheme.bodyLarge?.copyWith(
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  Widget _buildProfileImageSection() {
    return Column(
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Colors.grey[300]!, width: 2),
              ),
              child: ClipOval(
                child: _profileImage != null
                    ? Image.file(_profileImage!, fit: BoxFit.cover)
                    : Container(
                        color: Colors.grey[100],
                        child: Icon(
                          Icons.person,
                          size: 40,
                          color: Colors.grey[400],
                        ),
                      ),
              ),
            ),
            Positioned(
              bottom: 0,
              right: 0,
              child: Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 2),
                ),
                child: IconButton(
                  icon: const Icon(Icons.camera_alt, size: 16, color: Colors.white),
                  onPressed: _pickImage,
                  padding: EdgeInsets.zero,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          'صورة الملف الشخصي (اختياري)',
          style: TextStyle(
            color: Colors.grey[600],
            fontSize: 14,
          ),
        ),
      ],
    );
  }

  Widget _buildInputFields(ThemeData theme) {
    return Column(
      children: [
        // الاسم الكامل
        AuthTextField(
          controller: _fullNameController,
          label: 'الاسم الكامل',
          hintText: 'أدخل اسمك الكامل',
          prefixIcon: Icons.person_outline,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'يرجى إدخال الاسم الكامل';
            }
            if (value.trim().split(' ').length < 2) {
              return 'يرجى إدخال الاسم الكامل (الاسم واللقب)';
            }
            return null;
          },
        ),
        const SizedBox(height: 16),

        // البريد الإلكتروني
        AuthTextField(
          controller: _emailController,
          label: 'البريد الإلكتروني',
          hintText: 'أدخل بريدك الإلكتروني',
          prefixIcon: Icons.email_outlined,
          keyboardType: TextInputType.emailAddress,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'يرجى إدخال البريد الإلكتروني';
            }
            if (!EmailValidator.validate(value)) {
              return 'يرجى إدخال بريد إلكتروني صحيح';
            }
            return null;
          },
        ),
        const SizedBox(height: 16),

        // كلمة المرور
        AuthTextField(
          controller: _passwordController,
          label: 'كلمة المرور',
          hintText: 'أدخل كلمة المرور',
          prefixIcon: Icons.lock_outline,
          obscureText: true,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'يرجى إدخال كلمة المرور';
            }
            if (value.length < 6) {
              return 'كلمة المرور يجب أن تكون 6 أحرف على الأقل';
            }
            return null;
          },
        ),
        const SizedBox(height: 16),

        // تأكيد كلمة المرور
        AuthTextField(
          controller: _confirmPasswordController,
          label: 'تأكيد كلمة المرور',
          hintText: 'أعد إدخال كلمة المرور',
          prefixIcon: Icons.lock_outline,
          obscureText: true,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'يرجى تأكيد كلمة المرور';
            }
            if (value != _passwordController.text) {
              return 'كلمات المرور غير متطابقة';
            }
            return null;
          },
        ),
        const SizedBox(height: 16),

        // رقم الهاتف
        AuthTextField(
          controller: _phoneController,
          label: 'رقم الهاتف',
          hintText: 'أدخل رقم هاتفك',
          prefixIcon: Icons.phone_outlined,
          keyboardType: TextInputType.phone,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'يرجى إدخال رقم الهاتف';
            }
            if (!RegExp(r'^(\+213|0)(5|6|7)[0-9]{8}$').hasMatch(value)) {
              return 'يرجى إدخال رقم هاتف جزائري صحيح';
            }
            return null;
          },
        ),
      ],
    );
  }

  Widget _buildUserTypeSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'نوع المستخدم',
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: UserType.values.map((type) {
            final isSelected = _selectedUserType == type;
            return ChoiceChip(
              label: Text(type.arName),
              selected: isSelected,
              onSelected: (selected) {
                setState(() {
                  _selectedUserType = type;
                });
              },
              selectedColor: Theme.of(context).primaryColor.withOpacity(0.2),
              labelStyle: TextStyle(
                color: isSelected ? Theme.of(context).primaryColor : Colors.grey[700],
                fontWeight: FontWeight.w500,
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildLocationSection() {
    return LocationSelector(
      selectedWilaya: _selectedWilaya,
      selectedBaladiya: _selectedBaladiya,
      onWilayaChanged: (value) {
        setState(() {
          _selectedWilaya = value;
          _selectedBaladiya = null;
        });
      },
      onBaladiyaChanged: (value) {
        setState(() {
          _selectedBaladiya = value;
        });
      },
    );
  }

  Widget _buildTermsSection() {
    return Row(
      children: [
        Checkbox(
          value: _acceptTerms,
          onChanged: (value) {
            setState(() {
              _acceptTerms = value ?? false;
            });
          },
        ),
        Expanded(
          child: Wrap(
            children: [
              const Text('أوافق على '),
              GestureDetector(
                onTap: () => _showTermsDialog(),
                child: Text(
                  'شروط الاستخدام',
                  style: TextStyle(
                    color: Theme.of(context).primaryColor,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              const Text(' و '),
              GestureDetector(
                onTap: () => _showPrivacyDialog(),
                child: Text(
                  'سياسة الخصوصية',
                  style: TextStyle(
                    color: Theme.of(context).primaryColor,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildRegisterButton() {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: _isLoading ? null : _register,
        style: ElevatedButton.styleFrom(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        child: _isLoading
            ? const SizedBox(
                height: 20,
                width: 20,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor: AlwaysStoppedAnimation(Colors.white),
                ),
              )
            : const Text(
                'إنشاء حساب',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
      ),
    );
  }

  Widget _buildLoginLink() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'لديك حساب بالفعل؟',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(width: 8),
          TextButton(
            onPressed: _isLoading
                ? null
                : () {
                    context.go('/auth/login');
                  },
            child: const Text(
              'تسجيل الدخول',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showTermsDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('شروط الاستخدام'),
        content: SingleChildScrollView(
          child: Text(
            _termsAndConditions,
            style: const TextStyle(fontSize: 14, height: 1.5),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('حسناً'),
          ),
        ],
      ),
    );
  }

  void _showPrivacyDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('سياسة الخصوصية'),
        content: SingleChildScrollView(
          child: Text(
            _privacyPolicy,
            style: const TextStyle(fontSize: 14, height: 1.5),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('حسناً'),
          ),
        ],
      ),
    );
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.error_outline, color: Colors.red),
            SizedBox(width: 8),
            Text('خطأ'),
          ],
        ),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('حسناً'),
          ),
        ],
      ),
    );
  }
}

const String _termsAndConditions = '''
شروط استخدام منصة الفلاح الجزائري

1. القبول
باستخدامك لهذه المنصة، فإنك توافق على الالتزام بهذه الشروط والأحكام.

2. الالتزامات
- يجب أن تكون المعلومات المقدمة دقيقة وصحيحة
- يحظر استخدام المنصة لأغراض غير قانونية
- يجب الحفاظ على سرية معلومات الحساب

3. المحتوى
- أنت المسؤول عن جميع المحتويات التي تنشرها
- يحظر نشر محتوى مسيء أو غير قانوني
- تحتفظ الإدارة بحق حذف أي محتوى غير مناسب

4. الملكية الفكرية
جميع حقوق النشر والملكية الفكرية للمنصة محفوظة.
''';

const String _privacyPolicy = '''
سياسة الخصوصية

1. جمع المعلومات
نجمع المعلومات التي تقدمها لنا مباشرة عند التسجيل واستخدام الخدمة.

2. استخدام المعلومات
نستخدم معلوماتك لتقديم وتحسين الخدمات، والتواصل معك، وضمان الأمان.

3. حماية المعلومات
نحمي معلوماتك باستخدام إجراءات أمنية مناسبة ونلتزم بحماية خصوصيتك.

4. مشاركة المعلومات
لا نبيع أو نؤجر معلوماتك الشخصية لأطراف ثالثة دون موافقتك.
''';