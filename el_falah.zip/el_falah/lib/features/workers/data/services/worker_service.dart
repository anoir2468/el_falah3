// lib/features/workers/data/services/worker_service.dart
class WorkerService {
  final FirebaseFirestore _firestore;
  final StorageService _storageService;

  WorkerService({FirebaseFirestore? firestore, StorageService? storageService})
    : _firestore = firestore ?? FirebaseFirestore.instance,
      _storageService = storageService ?? StorageService();

  Stream<List<WorkerEntity>> getWorkersList({
    String? wilaya,
    WorkerSpecialty? specialty,
    double? minRate,
    double? maxRate,
    int? minExperience,
  }) {
    var query = _firestore
        .collection('workers')
        .where('isAvailable', isEqualTo: true)
        .orderBy('createdAt', descending: true);

    if (wilaya != null) {
      query = query.where('wilaya', isEqualTo: wilaya);
    }
    if (specialty != null) {
      query = query.where('specialties', arrayContains: specialty.name);
    }
    if (minRate != null) {
      query = query.where('dailyRate', isGreaterThanOrEqualTo: minRate);
    }
    if (maxRate != null) {
      query = query.where('dailyRate', isLessThanOrEqualTo: maxRate);
    }

    return query.snapshots().map((snapshot) {
      return snapshot.docs
          .map((doc) => WorkerEntity.fromMap(doc.data()))
          .toList();
    });
  }

  Future<String> addWorker(WorkerEntity worker) async {
    try {
      // رفع الصور
      String? profileImageUrl;
      if (worker.profileImage != null && worker.profileImage is File) {
        profileImageUrl = await _storageService.uploadImage(
          image: worker.profileImage as File,
          path: 'workers/${worker.id}/profile',
        );
      }

      final List<String> certificateUrls = [];
      for (final certFile in worker.certificateImages?.cast<File>() ?? []) {
        final url = await _storageService.uploadImage(
          image: certFile,
          path: 'workers/${worker.id}/certificates',
        );
        certificateUrls.add(url);
      }

      final List<String> workImageUrls = [];
      for (final workFile in worker.workImages?.cast<File>() ?? []) {
        final url = await _storageService.uploadImage(
          image: workFile,
          path: 'workers/${worker.id}/work',
        );
        workImageUrls.add(url);
      }

      // تحديث الكيان بروابط الصور
      final workerWithUrls = worker.copyWith(
        profileImage: profileImageUrl,
        certificateImages: certificateUrls,
        workImages: workImageUrls,
      );

      await _firestore
          .collection('workers')
          .doc(worker.id)
          .set(workerWithUrls.toMap());

      return worker.id;
    } catch (e) {
      throw Exception('فشل في إضافة العامل: $e');
    }
  }

  WorkerEntity copyWith({
    String? profileImage,
    List<String>? certificateImages,
    List<String>? workImages,
  }) {
    return WorkerEntity(
      id: id,
      fullName: fullName,
      age: age,
      specialties: specialties,
      experienceYears: experienceYears,
      wilaya: wilaya,
      baladiya: baladiya,
      phone: phone,
      email: email,
      profileImage: profileImage ?? this.profileImage,
      certificateImages: certificateImages ?? this.certificateImages,
      dailyRate: dailyRate,
      hourlyRate: hourlyRate,
      ownerId: ownerId,
      createdAt: createdAt,
      isAvailable: isAvailable,
      rating: rating,
      totalReviews: totalReviews,
      bio: bio,
      skills: skills,
      workImages: workImages ?? this.workImages,
    );
  }
}
