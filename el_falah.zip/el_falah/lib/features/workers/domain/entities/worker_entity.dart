// lib/features/workers/domain/entities/worker_entity.dart
@immutable
class WorkerEntity {
  final String id;
  final String fullName;
  final int age;
  final List<WorkerSpecialty> specialties;
  final int experienceYears;
  final String wilaya;
  final String baladiya;
  final String phone;
  final String? email;
  final String? profileImage;
  final List<String>? certificateImages;
  final double dailyRate;
  final double hourlyRate;
  final String ownerId;
  final DateTime createdAt;
  final bool isAvailable;
  final double rating;
  final int totalReviews;
  final String? bio;
  final List<String>? skills;
  final List<String>? workImages;

  const WorkerEntity({
    required this.id,
    required this.fullName,
    required this.age,
    required this.specialties,
    required this.experienceYears,
    required this.wilaya,
    required this.baladiya,
    required this.phone,
    this.email,
    this.profileImage,
    this.certificateImages,
    required this.dailyRate,
    required this.hourlyRate,
    required this.ownerId,
    required this.createdAt,
    this.isAvailable = true,
    this.rating = 0.0,
    this.totalReviews = 0,
    this.bio,
    this.skills,
    this.workImages,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'fullName': fullName,
      'age': age,
      'specialties': specialties.map((e) => e.name).toList(),
      'experienceYears': experienceYears,
      'wilaya': wilaya,
      'baladiya': baladiya,
      'phone': phone,
      'email': email,
      'profileImage': profileImage,
      'certificateImages': certificateImages,
      'dailyRate': dailyRate,
      'hourlyRate': hourlyRate,
      'ownerId': ownerId,
      'createdAt': createdAt.millisecondsSinceEpoch,
      'isAvailable': isAvailable,
      'rating': rating,
      'totalReviews': totalReviews,
      'bio': bio,
      'skills': skills,
      'workImages': workImages,
    };
  }

  factory WorkerEntity.fromMap(Map<String, dynamic> map) {
    return WorkerEntity(
      id: map['id'] ?? '',
      fullName: map['fullName'] ?? '',
      age: map['age'] ?? 0,
      specialties:
          (map['specialties'] as List<dynamic>?)
              ?.map(
                (e) => WorkerSpecialty.values.firstWhere(
                  (s) => s.name == e,
                  orElse: () => WorkerSpecialty.general,
                ),
              )
              .toList() ??
          [],
      experienceYears: map['experienceYears'] ?? 0,
      wilaya: map['wilaya'] ?? '',
      baladiya: map['baladiya'] ?? '',
      phone: map['phone'] ?? '',
      email: map['email'],
      profileImage: map['profileImage'],
      certificateImages: List<String>.from(map['certificateImages'] ?? []),
      dailyRate: (map['dailyRate'] ?? 0.0).toDouble(),
      hourlyRate: (map['hourlyRate'] ?? 0.0).toDouble(),
      ownerId: map['ownerId'] ?? '',
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['createdAt']),
      isAvailable: map['isAvailable'] ?? true,
      rating: (map['rating'] ?? 0.0).toDouble(),
      totalReviews: map['totalReviews'] ?? 0,
      bio: map['bio'],
      skills: List<String>.from(map['skills'] ?? []),
      workImages: List<String>.from(map['workImages'] ?? []),
    );
  }
}

enum WorkerSpecialty {
  harvesting('حصاد'),
  planting('زراعة'),
  irrigation('ري'),
  fertilization('تسميد'),
  pruning('تقليم'),
  pestControl('مكافحة الآفات'),
  general('عمالة عامة');

  const WorkerSpecialty(this.arName);
  final String arName;
}
