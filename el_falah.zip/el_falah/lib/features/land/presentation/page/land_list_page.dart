// lib/features/land/presentation/pages/land_list_page.dart
class LandListPage extends ConsumerWidget {
  const LandListPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final landAsync = ref.watch(landListProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('الأراضي والمنشآت')),
      body: landAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error:
            (error, stack) => Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error_outline, size: 64, color: Colors.grey),
                  const SizedBox(height: 16),
                  const Text('حدث خطأ في تحميل البيانات'),
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: () => ref.refresh(landListProvider),
                    child: const Text('إعادة المحاولة'),
                  ),
                ],
              ),
            ),
        data: (landList) {
          if (landList.isEmpty) {
            return _buildEmptyState(context);
          }
          return ListView.builder(
            itemCount: landList.length,
            itemBuilder: (context, index) {
              final land = landList[index];
              return _LandCard(land: land);
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          context.push('/land/add');
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.landscape, size: 80, color: Colors.grey[300]),
          const SizedBox(height: 16),
          Text(
            'لا توجد أراضي متاحة',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 8),
          Text(
            'كن أول من يضيف أرض إلى المنصة',
            textAlign: TextAlign.center,
            style: Theme.of(
              context,
            ).textTheme.bodyMedium?.copyWith(color: Colors.grey[600]),
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: () {
              context.push('/land/add');
            },
            child: const Text('إضافة أرض جديدة'),
          ),
        ],
      ),
    );
  }
}

class _LandCard extends StatelessWidget {
  final LandEntity land;

  const _LandCard({required this.land});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: InkWell(
        onTap: () {
          context.push('/land/${land.id}');
        },
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // صورة الأرض
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.grey[200],
                ),
                child:
                    land.images.isNotEmpty
                        ? ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.network(
                            land.images.first,
                            fit: BoxFit.cover,
                          ),
                        )
                        : Icon(
                          Icons.landscape,
                          size: 40,
                          color: Colors.grey[400],
                        ),
              ),
              const SizedBox(width: 16),

              // معلومات الأرض
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      land.title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      land.description,
                      style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Icon(
                          Icons.location_on,
                          size: 14,
                          color: Colors.grey[500],
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '${land.wilaya} - ${land.baladiya}',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey[500],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        _LandFeature(
                          icon: Icons.aspect_ratio,
                          text: '${land.area} هكتار',
                        ),
                        const SizedBox(width: 12),
                        _LandFeature(
                          icon: Icons.agriculture,
                          text: land.type.arName,
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '${land.price} د.ج',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.green,
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: _getSoilColor(land.soilType),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            land.soilType.arName,
                            style: const TextStyle(
                              fontSize: 12,
                              color: Colors.white,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getSoilColor(SoilType soilType) {
    switch (soilType) {
      case SoilType.loam:
        return Colors.brown;
      case SoilType.clay:
        return Colors.orange;
      case SoilType.sandy:
        return Colors.yellow[700]!;
      case SoilType.silt:
        return Colors.grey;
      case SoilType.chalky:
        return Colors.white;
    }
  }
}

class _LandFeature extends StatelessWidget {
  final IconData icon;
  final String text;

  const _LandFeature({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 14, color: Colors.grey[500]),
        const SizedBox(width: 4),
        Text(text, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
      ],
    );
  }
}
