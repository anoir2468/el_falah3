// lib/features/land/domain/entities/land_entity.dart
@immutable
class LandEntity {
  final String id;
  final String title;
  final String description;
  final double area; // بالهكتار
  final LandType type;
  final SoilType soilType;
  final double price;
  final String wilaya;
  final String baladiya;
  final List<String> images;
  final String ownerId;
  final DateTime createdAt;
  final bool isAvailable;
  final bool hasWater;
  final bool hasElectricity;
  final bool hasRoadAccess;
  final String? previousCrops;
  final String contactPhone;
  final String? contactEmail;
  final double? latitude;
  final double? longitude;

  const LandEntity({
    required this.id,
    required this.title,
    required this.description,
    required this.area,
    required this.type,
    required this.soilType,
    required this.price,
    required this.wilaya,
    required this.baladiya,
    required this.images,
    required this.ownerId,
    required this.createdAt,
    this.isAvailable = true,
    this.hasWater = false,
    this.hasElectricity = false,
    this.hasRoadAccess = false,
    this.previousCrops,
    required this.contactPhone,
    this.contactEmail,
    this.latitude,
    this.longitude,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'area': area,
      'type': type.name,
      'soilType': soilType.name,
      'price': price,
      'wilaya': wilaya,
      'baladiya': baladiya,
      'images': images,
      'ownerId': ownerId,
      'createdAt': createdAt.millisecondsSinceEpoch,
      'isAvailable': isAvailable,
      'hasWater': hasWater,
      'hasElectricity': hasElectricity,
      'hasRoadAccess': hasRoadAccess,
      'previousCrops': previousCrops,
      'contactPhone': contactPhone,
      'contactEmail': contactEmail,
      'latitude': latitude,
      'longitude': longitude,
    };
  }

  factory LandEntity.fromMap(Map<String, dynamic> map) {
    return LandEntity(
      id: map['id'] ?? '',
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      area: (map['area'] ?? 0.0).toDouble(),
      type: LandType.values.firstWhere(
        (e) => e.name == map['type'],
        orElse: () => LandType.farmland,
      ),
      soilType: SoilType.values.firstWhere(
        (e) => e.name == map['soilType'],
        orElse: () => SoilType.loam,
      ),
      price: (map['price'] ?? 0.0).toDouble(),
      wilaya: map['wilaya'] ?? '',
      baladiya: map['baladiya'] ?? '',
      images: List<String>.from(map['images'] ?? []),
      ownerId: map['ownerId'] ?? '',
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['createdAt']),
      isAvailable: map['isAvailable'] ?? true,
      hasWater: map['hasWater'] ?? false,
      hasElectricity: map['hasElectricity'] ?? false,
      hasRoadAccess: map['hasRoadAccess'] ?? false,
      previousCrops: map['previousCrops'],
      contactPhone: map['contactPhone'] ?? '',
      contactEmail: map['contactEmail'],
      latitude: map['latitude']?.toDouble(),
      longitude: map['longitude']?.toDouble(),
    );
  }
}

enum LandType {
  farmland('أرض زراعية'),
  greenhouse('بيت بلاستيكي'),
  orchard('بستان'),
  vineyard('كرم'),
  other('أخرى');

  const LandType(this.arName);
  final String arName;
}

enum SoilType {
  loam('طمي'),
  clay('طيني'),
  sandy('رملية'),
  silt('غرينية'),
  chalky('طباشيرية');

  const SoilType(this.arName);
  final String arName;
}
