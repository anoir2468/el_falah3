// lib/app/router/app_router.dart
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../features/auth/presentation/pages/login_page.dart';
import '../../features/auth/presentation/pages/register_page.dart';
import '../../features/auth/presentation/pages/forgot_password_page.dart';
import '../../features/home/presentation/pages/home_page.dart';
import '../../features/equipment/presentation/pages/equipment_list_page.dart';
import '../../features/equipment/presentation/pages/add_equipment_page.dart';
import '../../features/equipment/presentation/pages/equipment_detail_page.dart';
import '../../features/workers/presentation/pages/workers_list_page.dart';
import '../../features/workers/presentation/pages/add_worker_page.dart';
import '../../features/workers/presentation/pages/worker_detail_page.dart';
import '../../features/land/presentation/pages/land_list_page.dart';
import '../../features/land/presentation/pages/add_land_page.dart';
import '../../features/land/presentation/pages/land_detail_page.dart';
import '../../features/profile/presentation/pages/profile_page.dart';
import '../../features/profile/presentation/pages/edit_profile_page.dart';
import '../widgets/main_layout.dart';
import '../widgets/splash_screen.dart';

final appRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: '/splash',
    redirect: (context, state) {
      final authState = ref.read(authStateProvider);
      final isLoggedIn = authState.value != null;
      final isSplash = state.location == '/splash';
      final isAuthPage = state.location.startsWith('/auth');

      if (isSplash) return null;

      if (!isLoggedIn && !isAuthPage) {
        return '/auth/login';
      }

      if (isLoggedIn && isAuthPage) {
        return '/home';
      }

      return null;
    },
    routes: [
      // Splash Screen
      GoRoute(
        path: '/splash',
        name: 'splash',
        builder: (context, state) => const SplashScreen(),
      ),

      // Auth Routes
      GoRoute(
        path: '/auth/login',
        name: 'login',
        builder: (context, state) => const LoginPage(),
      ),
      GoRoute(
        path: '/auth/register',
        name: 'register',
        builder: (context, state) => const RegisterPage(),
      ),
      GoRoute(
        path: '/auth/forgot-password',
        name: 'forgot-password',
        builder: (context, state) => const ForgotPasswordPage(),
      ),

      // Main App with Bottom Navigation
      ShellRoute(
        builder: (context, state, child) => MainLayout(child: child),
        routes: [
          // Home
          GoRoute(
            path: '/home',
            name: 'home',
            builder: (context, state) => const HomePage(),
          ),

          // Equipment Routes
          GoRoute(
            path: '/equipment',
            name: 'equipment',
            builder: (context, state) => const EquipmentListPage(),
            routes: [
              GoRoute(
                path: 'add',
                name: 'add-equipment',
                builder: (context, state) => const AddEquipmentPage(),
              ),
              GoRoute(
                path: ':id',
                name: 'equipment-details',
                builder: (context, state) {
                  final id = state.pathParameters['id']!;
                  return EquipmentDetailPage(id: id);
                },
              ),
            ],
          ),

          // Workers Routes
          GoRoute(
            path: '/workers',
            name: 'workers',
            builder: (context, state) => const WorkersListPage(),
            routes: [
              GoRoute(
                path: 'add',
                name: 'add-worker',
                builder: (context, state) => const AddWorkerPage(),
              ),
              GoRoute(
                path: ':id',
                name: 'worker-details',
                builder: (context, state) {
                  final id = state.pathParameters['id']!;
                  return WorkerDetailPage(id: id);
                },
              ),
            ],
          ),

          // Land Routes
          GoRoute(
            path: '/land',
            name: 'land',
            builder: (context, state) => const LandListPage(),
            routes: [
              GoRoute(
                path: 'add',
                name: 'add-land',
                builder: (context, state) => const AddLandPage(),
              ),
              GoRoute(
                path: ':id',
                name: 'land-details',
                builder: (context, state) {
                  final id = state.pathParameters['id']!;
                  return LandDetailPage(id: id);
                },
              ),
            ],
          ),

          // Profile Routes
          GoRoute(
            path: '/profile',
            name: 'profile',
            builder: (context, state) => const ProfilePage(),
            routes: [
              GoRoute(
                path: 'edit',
                name: 'edit-profile',
                builder: (context, state) => const EditProfilePage(),
              ),
            ],
          ),
        ],
      ),
    ],
    errorBuilder:
        (context, state) => Scaffold(
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.error_outline, size: 64, color: Colors.grey),
                const SizedBox(height: 16),
                const Text(
                  'الصفحة غير موجودة',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text(
                  'عذراً، الصفحة التي تبحث عنها غير موجودة',
                  style: TextStyle(color: Colors.grey[600]),
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: () => context.go('/home'),
                  child: const Text('العودة للرئيسية'),
                ),
              ],
            ),
          ),
        ),
  );
});
