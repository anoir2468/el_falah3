package com.example.el_falah

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
