"use client"

import { useState, useEffect } from "react"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import algeriaRegions from "@/data/algeria-regions.json"

interface LocationSelectorProps {
  wilayaValue: string
  communeValue: string
  onWilayaChange: (value: string) => void
  onCommuneChange: (value: string) => void
  required?: boolean
}

export function LocationSelector({
  wilayaValue,
  communeValue,
  onWilayaChange,
  onCommuneChange,
  required = false,
}: LocationSelectorProps) {
  const [communes, setCommunes] = useState<{ commune_name: string }[]>([])

  useEffect(() => {
    if (wilayaValue) {
      const selectedWilaya = algeriaRegions.find((w) => w.wilaya_name === wilayaValue)
      setCommunes(selectedWilaya?.communes || [])
      onCommuneChange("")
    }
  }, [wilayaValue])

  return (
    <>
      <div className="space-y-2">
        <Label htmlFor="wilaya">الولاية {required && <span className="text-red-500">*</span>}</Label>
        <Select value={wilayaValue} onValueChange={onWilayaChange} required={required}>
          <SelectTrigger id="wilaya">
            <SelectValue placeholder="اختر الولاية" />
          </SelectTrigger>
          <SelectContent>
            {algeriaRegions.map((wilaya) => (
              <SelectItem key={wilaya.wilaya_code} value={wilaya.wilaya_name}>
                {wilaya.wilaya_name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="commune">البلدية {required && <span className="text-red-500">*</span>}</Label>
        <Select value={communeValue} onValueChange={onCommuneChange} required={required} disabled={!wilayaValue}>
          <SelectTrigger id="commune">
            <SelectValue placeholder={wilayaValue ? "اختر البلدية" : "اختر الولاية أولاً"} />
          </SelectTrigger>
          <SelectContent>
            {communes.map((commune, index) => (
              <SelectItem key={index} value={commune.commune_name}>
                {commune.commune_name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </>
  )
}
