import Link from "next/link"
import { Facebook, Twitter, Instagram, Mail, Phone, MapPin } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-[#1c1917] text-white mt-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* About */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#2d7a3e] to-[#10b981] flex items-center justify-center">
                <span className="text-white font-bold text-xl">ف</span>
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-lg leading-none">منصة الفلاح</span>
                <span className="text-xs text-gray-400">الجزائري</span>
              </div>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed">
              منصة شاملة تربط الفلاح الجزائري بكل ما يحتاجه من معدات، عمال، تدريب وموارد زراعية.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-bold mb-4">روابط سريعة</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/equipment" className="text-gray-400 hover:text-white transition-colors">
                  المعدات الزراعية
                </Link>
              </li>
              <li>
                <Link href="/workers" className="text-gray-400 hover:text-white transition-colors">
                  العمال
                </Link>
              </li>
              <li>
                <Link href="/training" className="text-gray-400 hover:text-white transition-colors">
                  التكوين والتدريب
                </Link>
              </li>
              <li>
                <Link href="/land" className="text-gray-400 hover:text-white transition-colors">
                  الأراضي الزراعية
                </Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-bold mb-4">خدماتنا</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/facilities" className="text-gray-400 hover:text-white transition-colors">
                  المنشآت الزراعية
                </Link>
              </li>
              <li>
                <Link href="/supplies" className="text-gray-400 hover:text-white transition-colors">
                  الأدوية والأسمدة
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-400 hover:text-white transition-colors">
                  من نحن
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-400 hover:text-white transition-colors">
                  اتصل بنا
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-bold mb-4">تواصل معنا</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2 text-gray-400">
                <Phone className="h-4 w-4" />
                <span>+213 XXX XXX XXX</span>
              </li>
              <li className="flex items-center gap-2 text-gray-400">
                <Mail className="h-4 w-4" />
                <span>info@fallah.dz</span>
              </li>
              <li className="flex items-center gap-2 text-gray-400">
                <MapPin className="h-4 w-4" />
                <span>الجزائر العاصمة، الجزائر</span>
              </li>
            </ul>
            <div className="flex gap-3 mt-4">
              <a
                href="#"
                className="w-8 h-8 rounded-full bg-gray-800 hover:bg-[#2d7a3e] flex items-center justify-center transition-colors"
              >
                <Facebook className="h-4 w-4" />
              </a>
              <a
                href="#"
                className="w-8 h-8 rounded-full bg-gray-800 hover:bg-[#2d7a3e] flex items-center justify-center transition-colors"
              >
                <Twitter className="h-4 w-4" />
              </a>
              <a
                href="#"
                className="w-8 h-8 rounded-full bg-gray-800 hover:bg-[#2d7a3e] flex items-center justify-center transition-colors"
              >
                <Instagram className="h-4 w-4" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
          <p>© 2025 منصة الفلاح الجزائري. جميع الحقوق محفوظة.</p>
        </div>
      </div>
    </footer>
  )
}
