"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Settings, Package, Users, Heart, ShoppingCart, Plus, Edit, Trash2, Eye } from "lucide-react"
import Image from "next/image"

export default function DashboardPage() {
  const userStats = [
    { label: "إعلاناتي النشطة", value: "12", icon: Package },
    { label: "الطلبات", value: "8", icon: ShoppingCart },
    { label: "المفضلة", value: "24", icon: Heart },
    { label: "التقييمات", value: "4.8", icon: Users },
  ]

  const myListings = [
    {
      id: 1,
      title: "جرار زراعي 75 حصان",
      category: "معدات",
      price: "2,500,000 دج",
      status: "نشط",
      views: 145,
      image: "/agricultural-tractor.jpg",
    },
    {
      id: 2,
      title: "أرض زراعية 5 هكتار",
      category: "أراضي",
      price: "15,000,000 دج",
      status: "نشط",
      views: 89,
      image: "/land-1.jpg",
    },
  ]

  const myOrders = [
    {
      id: 1,
      title: "نظام ري بالتنقيط",
      seller: "محمد بن علي",
      price: "85,000 دج",
      status: "قيد التوصيل",
      date: "2024-01-15",
    },
    {
      id: 2,
      title: "دورة الزراعة العضوية",
      seller: "معهد التكوين الزراعي",
      price: "12,000 دج",
      status: "مكتمل",
      date: "2024-01-10",
    },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 bg-muted/30 py-8">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          {/* Profile Header */}
          <Card className="p-6 mb-8">
            <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
              <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#2d7a3e] to-[#10b981] flex items-center justify-center text-white text-3xl font-bold">
                أح
              </div>
              <div className="flex-1">
                <h1 className="text-2xl font-bold text-foreground mb-1">أحمد حمزة</h1>
                <p className="text-muted-foreground mb-2">فلاح - ولاية سطيف</p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">عضو منذ 2023</Badge>
                  <Badge className="bg-[#2d7a3e]">موثق</Badge>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline">
                  <Settings className="h-4 w-4 ml-2" />
                  الإعدادات
                </Button>
                <Button className="bg-[#2d7a3e] hover:bg-[#1f5a2d]">
                  <Edit className="h-4 w-4 ml-2" />
                  تعديل الملف
                </Button>
              </div>
            </div>
          </Card>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {userStats.map((stat, index) => {
              const Icon = stat.icon
              return (
                <Card key={index} className="p-6">
                  <Icon className="h-8 w-8 text-[#2d7a3e] mb-3" />
                  <div className="text-3xl font-bold text-foreground mb-1">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </Card>
              )
            })}
          </div>

          {/* Tabs */}
          <Tabs defaultValue="listings" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3 lg:w-auto lg:inline-grid">
              <TabsTrigger value="listings">إعلاناتي</TabsTrigger>
              <TabsTrigger value="orders">طلباتي</TabsTrigger>
              <TabsTrigger value="favorites">المفضلة</TabsTrigger>
            </TabsList>

            <TabsContent value="listings" className="space-y-4">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-foreground">إعلاناتي النشطة</h2>
                <Button className="bg-[#2d7a3e] hover:bg-[#1f5a2d]">
                  <Plus className="h-4 w-4 ml-2" />
                  إضافة إعلان جديد
                </Button>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                {myListings.map((listing) => (
                  <Card key={listing.id} className="overflow-hidden">
                    <div className="relative h-48">
                      <Image
                        src={listing.image || "/placeholder.svg"}
                        alt={listing.title}
                        fill
                        className="object-cover"
                      />
                      <Badge className="absolute top-3 right-3 bg-green-500">{listing.status}</Badge>
                    </div>
                    <div className="p-4">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="font-bold text-foreground mb-1">{listing.title}</h3>
                          <p className="text-sm text-muted-foreground">{listing.category}</p>
                        </div>
                        <div className="text-left">
                          <div className="font-bold text-[#2d7a3e]">{listing.price}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
                        <Eye className="h-4 w-4" />
                        <span>{listing.views} مشاهدة</span>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                          <Edit className="h-4 w-4 ml-2" />
                          تعديل
                        </Button>
                        <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700 bg-transparent">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="orders" className="space-y-4">
              <h2 className="text-xl font-bold text-foreground mb-4">طلباتي</h2>
              <div className="space-y-4">
                {myOrders.map((order) => (
                  <Card key={order.id} className="p-6">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="flex-1">
                        <h3 className="font-bold text-foreground mb-1">{order.title}</h3>
                        <p className="text-sm text-muted-foreground mb-2">البائع: {order.seller}</p>
                        <p className="text-sm text-muted-foreground">التاريخ: {order.date}</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-left">
                          <div className="font-bold text-[#2d7a3e] mb-1">{order.price}</div>
                          <Badge variant={order.status === "مكتمل" ? "default" : "secondary"}>{order.status}</Badge>
                        </div>
                        <Button variant="outline" size="sm">
                          التفاصيل
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="favorites" className="space-y-4">
              <h2 className="text-xl font-bold text-foreground mb-4">المفضلة</h2>
              <div className="text-center py-12">
                <Heart className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">لم تقم بإضافة أي عناصر إلى المفضلة بعد</p>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
    </div>
  )
}
