"use client"

import type React from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { LocationSelector } from "@/components/location-selector"
import { Plus, Upload, X, Eye } from "lucide-react"
import { useState } from "react"

export default function AddTrainingPage() {
  const [coverImage, setCoverImage] = useState<string>("")
  const [showPreview, setShowPreview] = useState(false)
  const [formData, setFormData] = useState({
    title: "",
    category: "",
    level: "",
    duration: "",
    price: "",
    wilaya: "",
    commune: "",
    description: "",
    instructor: "",
    maxStudents: "",
    schedule: "",
    requirements: "",
    topics: [] as string[],
    isCertified: false,
    isOnline: false,
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("[v0] Training submission:", formData, coverImage)
    alert("تم نشر الدورة التدريبية بنجاح!")
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setCoverImage(URL.createObjectURL(file))
    }
  }

  const categories = [
    "زراعة الحبوب",
    "زراعة الخضروات",
    "زراعة الفواكه",
    "تربية المواشي",
    "البيوت البلاستيكية",
    "أنظمة الري الحديثة",
    "الزراعة العضوية",
    "إدارة المزارع",
    "أخرى",
  ]

  const levels = ["مبتدئ", "متوسط", "متقدم", "جميع المستويات"]

  const availableTopics = [
    "تحضير التربة",
    "الزراعة",
    "الري",
    "التسميد",
    "مكافحة الآفات",
    "الحصاد",
    "التسويق",
    "الإدارة المالية",
  ]

  const toggleTopic = (topic: string) => {
    setFormData({
      ...formData,
      topics: formData.topics.includes(topic)
        ? formData.topics.filter((t) => t !== topic)
        : [...formData.topics, topic],
    })
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 bg-muted/30 py-8">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">إضافة دورة تدريبية</h1>
              <p className="text-muted-foreground">املأ النموذج أدناه لإضافة دورة تدريبية زراعية</p>
            </div>
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowPreview(!showPreview)}
              className="bg-transparent"
            >
              <Eye className="h-4 w-4 ml-2" />
              {showPreview ? "إخفاء المعاينة" : "معاينة"}
            </Button>
          </div>

          {showPreview && (
            <Card className="p-6 mb-6 bg-blue-50 border-blue-200">
              <h3 className="text-lg font-bold mb-4 text-blue-900">معاينة الدورة</h3>
              <div className="bg-white rounded-lg overflow-hidden border border-border">
                {coverImage && (
                  <img src={coverImage || "/placeholder.svg"} alt="معاينة" className="w-full h-48 object-cover" />
                )}
                <div className="p-4">
                  <h4 className="text-xl font-bold text-foreground mb-2">{formData.title || "عنوان الدورة"}</h4>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                    <span>{formData.category || "الفئة"}</span>
                    <span>•</span>
                    <span>{formData.level || "المستوى"}</span>
                    <span>•</span>
                    <span>{formData.duration || "المدة"}</span>
                  </div>
                  <p className="text-2xl font-bold text-[#2d7a3e]">
                    {formData.price ? `${Number(formData.price).toLocaleString()} دج` : "السعر"}
                  </p>
                </div>
              </div>
            </Card>
          )}

          <form onSubmit={handleSubmit}>
            <Card className="p-6 mb-6">
              <h2 className="text-xl font-bold text-foreground mb-6">معلومات الدورة</h2>

              <div className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="title">
                    عنوان الدورة <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="title"
                    placeholder="مثال: دورة شاملة في الزراعة العضوية"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="category">
                      الفئة <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({ ...formData, category: value })}
                      required
                    >
                      <SelectTrigger id="category">
                        <SelectValue placeholder="اختر الفئة" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat} value={cat}>
                            {cat}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="level">
                      المستوى <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={formData.level}
                      onValueChange={(value) => setFormData({ ...formData, level: value })}
                      required
                    >
                      <SelectTrigger id="level">
                        <SelectValue placeholder="اختر المستوى" />
                      </SelectTrigger>
                      <SelectContent>
                        {levels.map((level) => (
                          <SelectItem key={level} value={level}>
                            {level}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="duration">
                      المدة <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="duration"
                      placeholder="مثال: 3 أسابيع، 20 ساعة"
                      value={formData.duration}
                      onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="price">
                      السعر (دج) <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="price"
                      type="number"
                      placeholder="0"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="instructor">
                      المدرب <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="instructor"
                      placeholder="اسم المدرب"
                      value={formData.instructor}
                      onChange={(e) => setFormData({ ...formData, instructor: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="maxStudents">
                      الحد الأقصى للطلاب <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="maxStudents"
                      type="number"
                      placeholder="0"
                      value={formData.maxStudents}
                      onChange={(e) => setFormData({ ...formData, maxStudents: e.target.value })}
                      required
                    />
                  </div>

                  <LocationSelector
                    wilayaValue={formData.wilaya}
                    communeValue={formData.commune}
                    onWilayaChange={(value) => setFormData({ ...formData, wilaya: value })}
                    onCommuneChange={(value) => setFormData({ ...formData, commune: value })}
                    required={!formData.isOnline}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="schedule">
                    الجدول الزمني <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="schedule"
                    placeholder="مثال: السبت والأربعاء من 9 صباحاً إلى 12 ظهراً"
                    value={formData.schedule}
                    onChange={(e) => setFormData({ ...formData, schedule: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>
                    المواضيع المغطاة <span className="text-red-500">*</span>
                  </Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {availableTopics.map((topic) => (
                      <div key={topic} className="flex items-center gap-2">
                        <Checkbox
                          id={topic}
                          checked={formData.topics.includes(topic)}
                          onCheckedChange={() => toggleTopic(topic)}
                        />
                        <Label htmlFor={topic} className="text-sm cursor-pointer">
                          {topic}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="requirements">
                    المتطلبات <span className="text-muted-foreground text-xs">(اختياري)</span>
                  </Label>
                  <Textarea
                    id="requirements"
                    placeholder="ما هي المتطلبات أو المعرفة المسبقة المطلوبة؟"
                    rows={3}
                    value={formData.requirements}
                    onChange={(e) => setFormData({ ...formData, requirements: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">
                    الوصف <span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    id="description"
                    placeholder="اكتب وصفاً تفصيلياً للدورة، ماذا سيتعلم الطلاب، الفوائد..."
                    rows={6}
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-4 pt-4 border-t border-border">
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="isCertified"
                      checked={formData.isCertified}
                      onCheckedChange={(checked) => setFormData({ ...formData, isCertified: checked as boolean })}
                    />
                    <Label htmlFor="isCertified" className="cursor-pointer">
                      شهادة معتمدة عند الانتهاء
                    </Label>
                  </div>

                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="isOnline"
                      checked={formData.isOnline}
                      onCheckedChange={(checked) => setFormData({ ...formData, isOnline: checked as boolean })}
                    />
                    <Label htmlFor="isOnline" className="cursor-pointer">
                      دورة عبر الإنترنت
                    </Label>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="p-6 mb-6">
              <h2 className="text-xl font-bold text-foreground mb-2">
                صورة الغلاف <span className="text-red-500">*</span>
              </h2>
              <p className="text-sm text-muted-foreground mb-6">أضف صورة جذابة تمثل الدورة التدريبية</p>
              <div className="space-y-4">
                {coverImage ? (
                  <div className="relative w-full h-64 rounded-lg border-2 border-border overflow-hidden">
                    <img
                      src={coverImage || "/placeholder.svg"}
                      alt="صورة الغلاف"
                      className="w-full h-full object-cover"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="icon"
                      className="absolute top-4 left-4"
                      onClick={() => setCoverImage("")}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <label className="w-full h-64 rounded-lg border-2 border-dashed border-border hover:border-[#2d7a3e] hover:bg-muted/50 transition-colors flex flex-col items-center justify-center gap-4 cursor-pointer">
                    <Upload className="h-12 w-12 text-muted-foreground" />
                    <div className="text-center">
                      <p className="text-sm font-medium text-foreground">انقر لرفع صورة الغلاف</p>
                      <p className="text-xs text-muted-foreground mt-1">PNG, JPG حتى 5MB</p>
                    </div>
                    <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                  </label>
                )}
              </div>
            </Card>

            <div className="flex gap-4">
              <Button type="submit" className="flex-1 bg-[#2d7a3e] hover:bg-[#1f5a2d] h-11" disabled={!coverImage}>
                <Plus className="h-5 w-5 ml-2" />
                نشر الدورة
              </Button>
              <Button type="button" variant="outline" className="h-11 bg-transparent">
                إلغاء
              </Button>
            </div>
          </form>
        </div>
      </main>
      <Footer />
    </div>
  )
}
