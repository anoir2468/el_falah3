import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter, GraduationCap, Clock, Star, Play, BookOpen, Award, Plus } from "lucide-react"
import Link from "next/link"

export default function TrainingPage() {
  const courses = [
    {
      id: 1,
      title: "أساسيات الزراعة الحديثة",
      instructor: "د. محمد العربي",
      category: "زراعة عامة",
      level: "مبتدئ",
      duration: "4 أسابيع",
      students: 245,
      rating: 4.8,
      reviews: 89,
      price: "15,000",
      image: "/course-1.jpg",
      lessons: 24,
      certificate: true,
    },
    {
      id: 2,
      title: "إدارة البيوت البلاستيكية",
      instructor: "م. فاطمة بن علي",
      category: "بيوت بلاستيكية",
      level: "متوسط",
      duration: "6 أسابيع",
      students: 178,
      rating: 4.9,
      reviews: 67,
      price: "25,000",
      image: "/course-2.jpg",
      lessons: 32,
      certificate: true,
    },
    {
      id: 3,
      title: "أنظمة الري الحديثة",
      instructor: "م. أحمد الحسني",
      category: "أنظمة ري",
      level: "متقدم",
      duration: "5 أسابيع",
      students: 156,
      rating: 4.7,
      reviews: 54,
      price: "20,000",
      image: "/course-3.jpg",
      lessons: 28,
      certificate: true,
    },
    {
      id: 4,
      title: "الزراعة العضوية المستدامة",
      instructor: "د. سعيد بلعيد",
      category: "زراعة عضوية",
      level: "مبتدئ",
      duration: "3 أسابيع",
      students: 312,
      rating: 4.9,
      reviews: 124,
      price: "12,000",
      image: "/course-4.jpg",
      lessons: 18,
      certificate: true,
    },
    {
      id: 5,
      title: "صيانة المعدات الزراعية",
      instructor: "م. يوسف مرزوق",
      category: "صيانة",
      level: "متوسط",
      duration: "4 أسابيع",
      students: 198,
      rating: 4.6,
      reviews: 72,
      price: "18,000",
      image: "/course-5.jpg",
      lessons: 26,
      certificate: true,
    },
    {
      id: 6,
      title: "مكافحة الآفات الزراعية",
      instructor: "د. خديجة العمري",
      category: "حماية النباتات",
      level: "متوسط",
      duration: "4 أسابيع",
      students: 223,
      rating: 4.8,
      reviews: 91,
      price: "16,000",
      image: "/course-6.jpg",
      lessons: 22,
      certificate: true,
    },
  ]

  const categories = [
    "جميع الفئات",
    "زراعة عامة",
    "بيوت بلاستيكية",
    "أنظمة ري",
    "زراعة عضوية",
    "صيانة",
    "حماية النباتات",
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-purple-600 to-pink-600 text-white py-12">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-3 mb-4">
              <GraduationCap className="h-10 w-10" />
              <h1 className="text-3xl sm:text-4xl font-bold">التكوين والتدريب</h1>
            </div>
            <p className="text-lg text-purple-50 max-w-2xl text-pretty">
              طور مهاراتك الزراعية مع دورات تدريبية متخصصة من خبراء في المجال
            </p>
          </div>
        </section>

        {/* Search and Filters */}
        <section className="bg-white border-b border-border sticky top-16 z-40 shadow-sm">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input placeholder="ابحث عن دورات..." className="pr-10 h-11" />
              </div>
              <Select defaultValue="all">
                <SelectTrigger className="w-full md:w-48 h-11">
                  <SelectValue placeholder="الفئة" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select defaultValue="all">
                <SelectTrigger className="w-full md:w-48 h-11">
                  <SelectValue placeholder="المستوى" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع المستويات</SelectItem>
                  <SelectItem value="beginner">مبتدئ</SelectItem>
                  <SelectItem value="intermediate">متوسط</SelectItem>
                  <SelectItem value="advanced">متقدم</SelectItem>
                </SelectContent>
              </Select>
              <Button className="bg-purple-600 hover:bg-purple-700 h-11">
                <Filter className="h-5 w-5 ml-2" />
                تصفية
              </Button>
            </div>
          </div>
        </section>

        {/* Courses Grid */}
        <section className="py-8">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center mb-6">
              <p className="text-muted-foreground">
                عرض <span className="font-bold text-foreground">{courses.length}</span> دورة تدريبية
              </p>
              <Link href="/training/add">
                <Button size="lg" className="bg-purple-600 text-white hover:bg-purple-700">
                  <Plus className="h-5 w-5 ml-2" />
                  أضف دورة تدريبية
                </Button>
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {courses.map((course) => (
                <Card
                  key={course.id}
                  className="overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
                >
                  <div className="relative">
                    <img
                      src={course.image || "/placeholder.svg"}
                      alt={course.title}
                      className="w-full h-48 object-cover"
                    />
                    <div className="absolute top-3 right-3">
                      <Badge className="bg-white text-foreground">{course.level}</Badge>
                    </div>
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                      <Button size="lg" className="bg-white text-purple-600 hover:bg-gray-100">
                        <Play className="h-5 w-5 ml-2" />
                        معاينة
                      </Button>
                    </div>
                  </div>
                  <div className="p-4">
                    <div className="mb-2">
                      <Badge variant="outline" className="text-xs">
                        {course.category}
                      </Badge>
                    </div>
                    <h3 className="text-lg font-bold text-foreground mb-2 line-clamp-2">{course.title}</h3>
                    <p className="text-sm text-muted-foreground mb-3">بواسطة {course.instructor}</p>

                    <div className="flex items-center gap-1 mb-3">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm font-bold">{course.rating}</span>
                      <span className="text-sm text-muted-foreground">({course.reviews})</span>
                      <span className="text-sm text-muted-foreground mr-auto">{course.students} طالب</span>
                    </div>

                    <div className="space-y-2 mb-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        <span>{course.duration}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <BookOpen className="h-4 w-4" />
                        <span>{course.lessons} درس</span>
                      </div>
                      {course.certificate && (
                        <div className="flex items-center gap-2">
                          <Award className="h-4 w-4" />
                          <span>شهادة إتمام</span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-border">
                      <div className="text-2xl font-bold text-purple-600">{course.price} دج</div>
                      <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                        سجل الآن
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            {/* Pagination */}
            <div className="flex justify-center gap-2 mt-8">
              <Button variant="outline" disabled>
                السابق
              </Button>
              <Button variant="outline" className="bg-purple-600 text-white hover:bg-purple-700 hover:text-white">
                1
              </Button>
              <Button variant="outline">2</Button>
              <Button variant="outline">3</Button>
              <Button variant="outline">التالي</Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
