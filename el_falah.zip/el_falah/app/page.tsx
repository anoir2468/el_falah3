import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import {
  Tractor,
  Users,
  GraduationCap,
  MapPin,
  Building2,
  Leaf,
  ArrowLeft,
  CheckCircle,
  TrendingUp,
  Shield,
} from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  const features = [
    {
      icon: Tractor,
      title: "معدات زراعية",
      description: "بيع وشراء المعدات الزراعية بكل سهولة مع خيارات الإيجار",
      href: "/equipment",
      color: "from-green-500 to-emerald-600",
    },
    {
      icon: Users,
      title: "إدارة العمال",
      description: "ابحث عن عمال مؤهلين أو قدم خدماتك كعامل زراعي",
      href: "/workers",
      color: "from-blue-500 to-cyan-600",
    },
    {
      icon: GraduationCap,
      title: "التكوين والتدريب",
      description: "دورات تدريبية متخصصة لتطوير مهاراتك الزراعية",
      href: "/training",
      color: "from-purple-500 to-pink-600",
    },
    {
      icon: MapPin,
      title: "الأراضي الزراعية",
      description: "اشتري أو استأجر أراضي زراعية في مختلف الولايات",
      href: "/land",
      color: "from-amber-500 to-orange-600",
    },
    {
      icon: Building2,
      title: "المنشآت الزراعية",
      description: "بيوت بلاستيكية ومنشآت زراعية حديثة",
      href: "/facilities",
      color: "from-teal-500 to-green-600",
    },
    {
      icon: Leaf,
      title: "الأدوية والأسمدة",
      description: "مستلزمات زراعية عالية الجودة لمحاصيل أفضل",
      href: "/supplies",
      color: "from-lime-500 to-green-600",
    },
  ]

  const stats = [
    { label: "فلاح مسجل", value: "10,000+" },
    { label: "معدة متوفرة", value: "5,000+" },
    { label: "عامل نشط", value: "3,000+" },
    { label: "دورة تدريبية", value: "200+" },
  ]

  const benefits = ["منصة آمنة وموثوقة", "أسعار تنافسية", "دعم فني متواصل", "تغطية جميع الولايات"]

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-[#2d7a3e] via-[#1f5a2d] to-[#10b981] text-white overflow-hidden">
          <div className="absolute inset-0 bg-[url('/agricultural-field-pattern.jpg')] opacity-10 bg-cover bg-center" />
          <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20 sm:py-32">
            <div className="max-w-3xl">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight text-balance mb-6">
                منصة شاملة للفلاح الجزائري
              </h1>
              <p className="text-lg sm:text-xl text-green-50 leading-relaxed mb-8 text-pretty">
                كل ما يحتاجه الفلاح في مكان واحد - من المعدات والعمال إلى التدريب والموارد الزراعية
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-white text-[#2d7a3e] hover:bg-gray-100 text-lg h-12">
                  ابدأ الآن
                  <ArrowLeft className="mr-2 h-5 w-5" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white/10 text-lg h-12 bg-transparent"
                >
                  تعرف على المزيد
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="bg-white border-b border-border">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-3xl sm:text-4xl font-bold text-[#2d7a3e] mb-2">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">خدماتنا المتكاملة</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
                نوفر لك جميع الخدمات التي تحتاجها لتطوير مشروعك الزراعي
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {features.map((feature, index) => {
                const Icon = feature.icon
                return (
                  <Link key={index} href={feature.href}>
                    <Card className="p-6 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer h-full border-2 hover:border-[#2d7a3e]">
                      <div
                        className={`w-12 h-12 rounded-lg bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4`}
                      >
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <h3 className="text-xl font-bold text-foreground mb-2">{feature.title}</h3>
                      <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                    </Card>
                  </Link>
                )
              })}
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="bg-muted py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6">لماذا تختار منصتنا؟</h2>
                <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                  نحن نفهم احتياجات الفلاح الجزائري ونعمل على توفير أفضل الحلول لتطوير القطاع الزراعي
                </p>
                <div className="space-y-4">
                  {benefits.map((benefit, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <CheckCircle className="h-6 w-6 text-[#2d7a3e] flex-shrink-0" />
                      <span className="text-foreground font-medium">{benefit}</span>
                    </div>
                  ))}
                </div>
                <Button size="lg" className="mt-8 bg-[#2d7a3e] hover:bg-[#1f5a2d]">
                  انضم إلينا الآن
                  <ArrowLeft className="mr-2 h-5 w-5" />
                </Button>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <Card className="p-6 text-center">
                  <TrendingUp className="h-8 w-8 text-[#2d7a3e] mx-auto mb-3" />
                  <h4 className="font-bold text-foreground mb-2">نمو مستمر</h4>
                  <p className="text-sm text-muted-foreground">منصة في تطور دائم</p>
                </Card>
                <Card className="p-6 text-center mt-8">
                  <Shield className="h-8 w-8 text-[#2d7a3e] mx-auto mb-3" />
                  <h4 className="font-bold text-foreground mb-2">أمان عالي</h4>
                  <p className="text-sm text-muted-foreground">حماية بياناتك أولوية</p>
                </Card>
                <Card className="p-6 text-center">
                  <Users className="h-8 w-8 text-[#2d7a3e] mx-auto mb-3" />
                  <h4 className="font-bold text-foreground mb-2">مجتمع نشط</h4>
                  <p className="text-sm text-muted-foreground">آلاف الفلاحين معنا</p>
                </Card>
                <Card className="p-6 text-center mt-8">
                  <Leaf className="h-8 w-8 text-[#2d7a3e] mx-auto mb-3" />
                  <h4 className="font-bold text-foreground mb-2">جودة عالية</h4>
                  <p className="text-sm text-muted-foreground">منتجات موثوقة</p>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <Card className="bg-gradient-to-br from-[#2d7a3e] to-[#10b981] text-white p-12 text-center">
              <h2 className="text-3xl sm:text-4xl font-bold mb-4">هل أنت مستعد للبدء؟</h2>
              <p className="text-lg text-green-50 mb-8 max-w-2xl mx-auto text-pretty">
                انضم إلى آلاف الفلاحين الذين يستخدمون منصتنا لتطوير مشاريعهم الزراعية
              </p>
              <Button size="lg" className="bg-white text-[#2d7a3e] hover:bg-gray-100 text-lg h-12">
                إنشاء حساب مجاني
                <ArrowLeft className="mr-2 h-5 w-5" />
              </Button>
            </Card>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
