import { redirect } from "next/navigation"

export default function FacilitiesPage() {
  redirect("/land")
}
